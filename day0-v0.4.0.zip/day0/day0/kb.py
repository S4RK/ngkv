"""v0.4 — curated knowledge base of parameters and combinations that work.

Two stores, deliberately separate:
  registry (priors.py)  — MEASURED outcomes, auto-written, never hand-edited.
  kb/ (this module)     — CURATED engineering knowledge: per-family YAML with
                          constraints, known-good/known-bad configs, engine notes.
                          Every entry carries an evidence tag:
                            measured  — full day0 benchmark behind it
                            smoke     — launched + healthy, not benchmarked
                            community — vendor/community reported, unverified here
                          Claims never exceed their evidence.

At search time: vetoes prune candidates (with the KB reason cited), seeds are
promoted to the front of screening with a guaranteed halve slot (priors-style:
they order the search; measurement still decides), notes flow to the report.

Location: repo kb/ by default; set DAY0_KB to a shared path (git repo, NFS)
to share one KB across nodes and people.
"""
from __future__ import annotations

import fnmatch
import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .introspect import ModelFacts
from .search_space import Candidate

_DEFAULT_KB = Path(__file__).parent.parent / "kb"


def kb_dir() -> Path:
    return Path(os.environ.get("DAY0_KB", str(_DEFAULT_KB)))


@dataclass
class KBEntry:
    name: str
    match: dict
    constraints: list[dict] = field(default_factory=list)
    known_good: list[dict] = field(default_factory=list)
    known_bad: list[dict] = field(default_factory=list)
    engine_notes: dict = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    source_file: str = ""


def _matches(entry: KBEntry, facts: ModelFacts) -> bool:
    m = entry.match or {}
    for pat in m.get("model_ids", []):
        if fnmatch.fnmatch(facts.model_id, pat):
            return True
    for pat in m.get("architectures", []):
        if fnmatch.fnmatch(facts.architecture, pat):
            return True
    return False


def load(facts: ModelFacts) -> list[KBEntry]:
    d = kb_dir()
    if not d.exists():
        return []
    out = []
    for p in sorted(d.glob("*.yaml")):
        try:
            raw = yaml.safe_load(p.read_text()) or {}
        except Exception:
            continue
        e = KBEntry(name=raw.get("name", p.stem), match=raw.get("match", {}),
                    constraints=raw.get("constraints", []) or [],
                    known_good=raw.get("known_good", []) or [],
                    known_bad=raw.get("known_bad", []) or [],
                    engine_notes=raw.get("engine_notes", {}) or {},
                    notes=raw.get("notes", []) or [], source_file=p.name)
        if _matches(e, facts):
            out.append(e)
    return out


def _cfg_matches(pattern: dict, c: Candidate) -> bool:
    """Every key present in the pattern must equal the candidate's value.
    Special comparators: {axis: {gt: v}} / {lt: v} for ranges."""
    for k, want in (pattern or {}).items():
        have = getattr(c, k, None)
        if isinstance(want, dict):
            if "gt" in want and not (have is not None and have > want["gt"]):
                return False
            if "lt" in want and not (have is not None and have < want["lt"]):
                return False
        elif have != want:
            return False
    return True


def veto(entries: list[KBEntry], c: Candidate) -> str | None:
    """Returns the KB reason if a known-bad pattern matches this candidate."""
    for e in entries:
        for kb in e.known_bad:
            if _cfg_matches(kb.get("config", {}), c):
                ev = kb.get("evidence", "community")
                return (f"kb:{e.source_file} [{ev}]: "
                        f"{kb.get('reason', 'known-bad configuration')}")
    return None


def seeds(entries: list[KBEntry], cands: list[Candidate]
          ) -> tuple[set[str], list[str]]:
    """cids of candidates matching known-good patterns, with rationales."""
    promoted: set[str] = set()
    why: list[str] = []
    for e in entries:
        for kg in e.known_good:
            pat = kg.get("config", {})
            for c in cands:
                if c.cid in promoted or not _cfg_matches(pat, c):
                    continue
                promoted.add(c.cid)
                why.append(f"kb seed {c.cid} ({c.label()}): {e.source_file} "
                           f"[{kg.get('evidence', 'community')}] "
                           f"{kg.get('note', '')}".rstrip())
                break
    return promoted, why


def all_notes(entries: list[KBEntry]) -> list[str]:
    out = []
    for e in entries:
        out += [f"[{e.source_file}] {n}" for n in e.notes]
        for eng, note in e.engine_notes.items():
            out.append(f"[{e.source_file}] {eng}: {note}")
    return out


def draft_from_run(runs_sqlite: Path, out_dir: Path | None = None) -> Path:
    """`day0 kb learn`: distill a completed run into a draft KB entry for
    human review — champion as known_good [measured], crash families as
    known_bad [measured]. Drafts land in kb/drafts/ and are NOT loaded
    until a human moves them up and prunes them."""
    import json
    import sqlite3
    db = sqlite3.connect(runs_sqlite)
    meta = dict(db.execute("SELECT k, v FROM meta").fetchall())
    facts = json.loads(meta.get("model_facts", "{}"))
    mode = json.loads(meta.get("mode", '"cluster"'))
    ev = "measured" if mode == "cluster" else "smoke"
    best = db.execute("SELECT config_json, score FROM trials WHERE status='ok' "
                      "ORDER BY score DESC LIMIT 1").fetchone()
    crashes = db.execute(
        "SELECT substr(reason,1,120), config_json, COUNT(*) FROM trials "
        "WHERE status='crash' GROUP BY substr(reason,1,120) "
        "ORDER BY 3 DESC LIMIT 8").fetchall()
    entry: dict = {
        "name": f"draft-{facts.get('model_id', 'unknown').split('/')[-1]}",
        "match": {"model_ids": [facts.get("model_id", "*")]},
        "known_good": [], "known_bad": [], "notes":
            [f"auto-drafted from {runs_sqlite}; review, prune, then move out of drafts/"],
    }
    if best:
        cfg = json.loads(best[0])
        axes = {k: cfg[k] for k in ("serving_mode", "tp", "ep", "dp", "quant",
                                    "kv_dtype", "chunked_prefill", "spec_decode",
                                    "hicache", "engine") if k in cfg}
        entry["known_good"].append({"config": axes, "evidence": ev,
                                    "note": f"run champion @ {best[1]:.0f} out tok/s goodput"})
    for reason, cfg_json, n in crashes:
        cfg = json.loads(cfg_json)
        entry["known_bad"].append({
            "config": {k: cfg[k] for k in ("engine", "serving_mode", "dp", "ep")
                       if k in cfg},
            "evidence": ev, "reason": f"({n}x) {reason}"})
    d = (out_dir or kb_dir()) / "drafts"
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"{entry['name']}.yaml"
    p.write_text(yaml.safe_dump(entry, sort_keys=False, allow_unicode=True))
    return p
