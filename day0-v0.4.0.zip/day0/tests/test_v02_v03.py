import json
import random
import subprocess
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from day0.job import load_job                          # noqa: E402
from day0.introspect import introspect                 # noqa: E402
from day0 import bayes, priors, scheduler, search_space  # noqa: E402
from day0.engines import trtllm                        # noqa: E402
from day0.search_space import Candidate                # noqa: E402

JOB = ROOT / "configs" / "example-job.yaml"
CFG = json.loads((ROOT / "configs" / "cached_model_configs" /
                  "deepseek-ai__DeepSeek-V4-Flash-0731.json").read_text())


def facts():
    return introspect("deepseek-ai/DeepSeek-V4-Flash-0731", config_override=CFG)


# ---------------- v0.2: scheduler ----------------

def test_node_pool_never_oversubscribes():
    pool = scheduler.NodePool(2)
    in_use, max_seen, lock = [0], [0], threading.Lock()

    def worker(n):
        with pool.acquire(n) as nodes:
            with lock:
                in_use[0] += len(nodes)
                max_seen[0] = max(max_seen[0], in_use[0])
            time.sleep(0.01)
            with lock:
                in_use[0] -= len(nodes)

    threads = [threading.Thread(target=worker, args=(n,))
               for n in (2, 1, 1, 2, 1, 1, 2)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=10)
    assert max_seen[0] <= 2


def test_nodes_needed_pd_and_single_node():
    j = load_job(JOB)
    pd = Candidate("B", "pd_disagg", 8, 8, 1, 1, "fp8", "bf16", 4096, 512, 0,
                   "off", pd_split="1P1D-node")
    assert scheduler.nodes_needed(pd, j) == 2
    single = Candidate("D", "aggregated", 8, 8, 1, 1, "fp8", "bf16", 8192, 512, 0, "off")
    assert scheduler.nodes_needed(single, j) == 1
    full = Candidate("A", "aggregated", 8, 8, 2, 1, "fp8", "bf16", 8192, 512, 0, "off")
    assert scheduler.nodes_needed(full, j) == 2


def test_budget_shortens_ladder_when_over():
    j = load_job(JOB)
    b = scheduler.Budget.from_job(j)
    cap = b.phase_cap("refine")
    b.charge("refine", cap * 0.95)
    assert b.ladder_factor("refine", cap * 0.2) < 1.0
    assert b.ladder_factor("search", 10.0) == 1.0


# ---------------- v0.3: TPE ----------------

def test_tpe_beats_random_on_synthetic():
    space = bayes.REFINE_AXES
    optimum = {"chunked_prefill": 8192, "max_running_reqs": 384,
               "kv_dtype": "fp8", "spec_decode": 2, "hicache": "l2"}

    def f(x):
        return sum(3.0 if x[a] == optimum[a] else 0.0 for a in space) \
            - 0.001 * abs(hash(tuple(sorted(x.items())))) % 1

    def run(strategy_rng, use_tpe):
        hist = []
        for _ in range(30):
            if use_tpe:
                x = bayes.tpe_suggest(hist, space, strategy_rng)
            else:
                x = {a: strategy_rng.choice(vs) for a, vs in space.items()}
            hist.append((x, f(x)))
        return max(h[1] for h in hist)

    tpe_wins = sum(run(random.Random(1000 + s), True)
                   >= run(random.Random(2000 + s), False) for s in range(5))
    assert tpe_wins >= 3          # TPE at least matches random most seeds


def test_refine_space_respects_engine_and_mtp():
    c_sgl = Candidate("A", "aggregated", 8, 8, 2, 1, "fp8", "bf16", 8192, 512, 0, "off")
    s = bayes.refine_space(c_sgl, mtp=False)
    assert s["spec_decode"] == [0]
    c_trt = Candidate("E", "aggregated", 8, 8, 1, 1, "fp8", "bf16", 8192, 512, 0,
                      "off", engine="trtllm")
    s = bayes.refine_space(c_trt, mtp=True)
    assert s["hicache"] == ["off"] and s["spec_decode"] == [0]


# ---------------- v0.3: priors ----------------

def test_warm_start_promotes_matching_config(tmp_path, monkeypatch):
    monkeypatch.setenv("DAY0_REGISTRY", str(tmp_path))
    f, j = facts(), load_job(JOB)
    cands, _ = search_space.generate(f, j)
    a_cands = [c for c in cands if c.track == "A"]
    target = a_cands[len(a_cands) // 2]
    priors.record_run(f, target.__dict__ | {"cid": target.cid}, 40000.0,
                      "testjob", "simulate")
    ordered, promoted, why = priors.warm_start(f, a_cands)
    assert promoted, "expected at least one promotion"
    assert ordered[0].cid in promoted
    assert "similarity" in why[0]


def test_warm_start_ignores_dissimilar_models(tmp_path, monkeypatch):
    monkeypatch.setenv("DAY0_REGISTRY", str(tmp_path))
    f, j = facts(), load_job(JOB)
    cands, _ = search_space.generate(f, j)
    dense_facts = {"attention_type": "gqa", "is_moe": False,
                   "total_params_b": 8.0, "has_mtp_head": False}
    rec = {"ts": 0, "job_digest": "x", "mode": "simulate",
           "model_facts": dense_facts,
           "winner": cands[0].__dict__ | {"cid": cands[0].cid}, "score": 1.0}
    (tmp_path / "x-0.json").write_text(json.dumps(rec))
    _, promoted, _ = priors.warm_start(f, cands)
    assert not promoted


# ---------------- v0.3: trtllm ----------------

def test_trtllm_cmd_builder():
    j = load_job(JOB)
    c = Candidate("E", "aggregated", 8, 8, 1, 1, "fp8", "fp8", 8192, 512, 0,
                  "off", engine="trtllm")
    cmd = trtllm.launch_cmd(c, j)
    assert cmd[0] == "trtllm-serve"
    assert "--tp_size" in cmd and cmd[cmd.index("--tp_size") + 1] == "8"
    assert "--kv_cache_dtype" in cmd
    pd = Candidate("E", "pd_disagg", 8, 8, 1, 1, "fp8", "bf16", 8192, 512, 0,
                   "off", engine="trtllm", pd_split="1P1D-node")
    try:
        trtllm.launch_cmd(pd, j)
        raise AssertionError("expected ValueError for pd_disagg on trtllm v0.3")
    except ValueError:
        pass


# ---------------- v0.2+v0.3: e2e with all five tracks ----------------

def test_e2e_five_tracks_with_registry(tmp_path):
    reg = tmp_path / "reg"
    env = {"DAY0_REGISTRY": str(reg), "PATH": "/usr/bin:/bin"}
    out1 = tmp_path / "r1"
    r = subprocess.run([sys.executable, "-m", "day0.cli", "run", str(JOB),
                        "--simulate", "--out", str(out1)],
                       cwd=ROOT, capture_output=True, text=True, timeout=600, env=env)
    assert r.returncode == 0, r.stderr
    rpt = (out1 / "report.md").read_text()
    assert "Multi-engine bake-off (TRT-LLM)" in rpt
    assert len(list(reg.glob("*.json"))) == 1
    # second run warm-starts from the first
    out2 = tmp_path / "r2"
    r2 = subprocess.run([sys.executable, "-m", "day0.cli", "run", str(JOB),
                         "--simulate", "--out", str(out2)],
                        cwd=ROOT, capture_output=True, text=True, timeout=600, env=env)
    assert r2.returncode == 0, r2.stderr
    assert "warm-start" in r2.stdout


# ---------------- v0.3.1: multimodal nested config ----------------

def test_introspect_unwraps_text_config():
    # synthetic fixture exercising the Gemma-style nesting, not real Gemma values
    nested = {
        "architectures": ["SomeMultimodalForConditionalGeneration"],
        "vision_config": {"hidden_size": 1152},
        "text_config": {
            "num_hidden_layers": 48, "hidden_size": 3840,
            "num_attention_heads": 16, "num_key_value_heads": 8,
            "head_dim": 256, "intermediate_size": 15360,
            "num_experts": 64, "num_experts_per_tok": 4,
            "vocab_size": 262144, "max_position_embeddings": 262144,
        },
    }
    f = introspect("test/nested-model", config_override=nested)
    assert f.n_layers == 48 and f.hidden_size == 3840
    assert f.attention_type == "gqa"
    assert f.is_moe and f.n_experts == 64
    assert any("multimodal" in n for n in f.notes)


def test_introspect_real_gemma4_config():
    """Fixture is the actual google/gemma-4-26B-A4B-it config.json (public)."""
    cfg = json.loads((ROOT / "configs" / "cached_model_configs" /
                      "google__gemma-4-26B-A4B-it.json").read_text())
    f = introspect("google/gemma-4-26B-A4B-it", config_override=cfg)
    assert f.is_moe and f.n_experts == 128
    assert f.experts_per_tok == 8              # via top_k_experts alias
    assert 3.0 < f.active_params_b < 5.0       # A4B
    assert 20 < f.total_params_b < 32          # 26B-class
    assert f.attention_type == "gqa" and not f.has_mtp_head
    assert any("hybrid attention" in n for n in f.notes)


def test_sglang_tp_dp_semantics():
    """SGLang requires tp_size % dp_size == 0 with tp_size = total world."""
    from day0.engines import sglang as sgl
    f, j = facts(), load_job(JOB)
    cands, _ = search_space.generate(f, j)
    for c in (x for x in cands if x.engine == "sglang"):
        cmd = sgl.launch_cmd(c, j)
        tp = int(cmd[cmd.index("--tp-size") + 1])
        assert tp == c.tp * c.dp
        if "--dp-size" in cmd:
            dp = int(cmd[cmd.index("--dp-size") + 1])
            assert tp % dp == 0 and "--enable-dp-attention" in cmd


def test_vector_width_rule_gemma4():
    from day0 import feasibility as fz
    cfg = json.loads((ROOT / "configs" / "cached_model_configs" /
                      "google__gemma-4-26B-A4B-it.json").read_text())
    g = introspect("google/gemma-4-26B-A4B-it", config_override=cfg)
    j = load_job(JOB)
    v = fz.check(g, j, tp=8, ep=1, pp=1, dp=1, quant="bf16", kv_dtype="bf16",
                 min_kv_tokens=100_000)
    assert not v.ok and "vector width" in v.reason          # 704/8=88: the live crash
    v = fz.check(g, j, tp=8, ep=8, pp=1, dp=1, quant="bf16", kv_dtype="bf16",
                 min_kv_tokens=100_000)
    assert v.ok, v.reason                                    # whole experts via EP
    v = fz.check(g, j, tp=4, ep=1, pp=1, dp=1, quant="bf16", kv_dtype="bf16",
                 min_kv_tokens=100_000)
    assert v.ok, v.reason                                    # 704/4=176: passed live
    # DeepSeek layouts must be unaffected by the new rule
    d = facts()
    v = fz.check(d, j, tp=8, ep=8, pp=1, dp=2, quant="fp8", kv_dtype="bf16")
    assert v.ok, v.reason


def test_no_deprecated_ep_flag():
    from day0.engines import sglang as sgl
    f, j = facts(), load_job(JOB)
    cands, _ = search_space.generate(f, j)
    for c in (x for x in cands if x.engine == "sglang" and x.ep > 1):
        assert "--enable-ep-moe" not in sgl.launch_cmd(c, j)


def test_kill_tree_reaps_children():
    """Engine + its children die on teardown; day0's own group is untouched."""
    import os
    import subprocess as sp
    from day0.runner import launch_isolated, kill_tree
    proc = launch_isolated(["bash", "-c", "sleep 30 & sleep 30 & wait"])
    time.sleep(0.3)
    assert os.getpgid(proc.pid) == proc.pid          # own session
    assert os.getpgid(proc.pid) != os.getpgid(0)     # not day0's group
    kill_tree(proc, grace_s=5)
    assert proc.poll() is not None
    live = ["?"]
    for _ in range(30):                               # zombies (unreaped, no init) are fine
        r = sp.run(["ps", "-o", "stat=", "-g", str(proc.pid)],
                   capture_output=True, text=True)
        live = [x for x in r.stdout.split() if not x.startswith("Z")]
        if not live:
            break
        time.sleep(0.1)
    assert not live, f"live survivors in engine group: {live}"


def test_track_exception_does_not_kill_run(tmp_path):
    from day0.job import load_job as lj
    from day0.store import Store
    from day0 import scheduler as sch
    j = lj(JOB)
    st = Store(tmp_path / "t.sqlite")

    def bad_track(track, cands, job, facts, store, *, simulate, pool, budget):
        if track == "A":
            raise RuntimeError("boom")
        return "champ-" + track

    champs = sch.run_tracks({"A": [1], "C": [1]}, j, facts(), st,
                            simulate=True, halving_fn=bad_track)
    assert champs == {"C": "champ-C"}
    rows = st.db.execute("SELECT rationale FROM decisions WHERE stage='scheduler'").fetchall()
    assert any("ABORTED" in r[0] for r in rows)


def _agg_record(**over):
    base = {"duration": 189.24, "completed": 1440,
            "input_throughput": 11755.79, "output_throughput": 5830.51,
            "median_ttft_ms": 111.59, "p90_ttft_ms": 167.9,
            "p95_ttft_ms": 186.22, "p99_ttft_ms": 237.13,
            "median_tpot_ms": 11.07, "p90_tpot_ms": 13.81,
            "p95_tpot_ms": 14.7, "p99_tpot_ms": 15.55}
    base.update(over)
    return base


def test_summarize_real_schema_with_details(tmp_path):
    from day0.bench.harness import summarize
    j = load_job(JOB)
    rec = _agg_record(
        ttfts=[0.1, 0.15, 3.5, 0.12],          # one TTFT SLO violator (3.5s > 2.0s)
        itls=[[0.010] * 5, [0.011] * 5, [0.012] * 5, [0.060] * 5],  # one TPOT violator (60ms)
        output_lens=[100, 100, 100, 100],
        errors=[None, None, None, None])
    p = tmp_path / "r.jsonl"
    p.write_text(json.dumps(rec) + "\n")
    r = summarize(p, j, j.profiles[0], 8.0)
    assert abs(r.slo_attainment - 0.5) < 1e-9          # 2 of 4 meet both SLOs
    assert abs(r.goodput_output_tps - 200 / 189.24) < 1e-6
    assert r.ttft_p95_s > 2.0                           # violator visible in p95


def test_summarize_aggregate_fallback(tmp_path):
    from day0.bench.harness import summarize
    j = load_job(JOB)
    p = tmp_path / "r.jsonl"
    p.write_text(json.dumps(_agg_record()) + "\n")
    r = summarize(p, j, j.profiles[0], 8.0)
    # the live Gemma numbers: p99s far inside both SLOs -> full attainment
    assert r.slo_attainment == 1.0
    assert abs(r.goodput_output_tps - 5830.51) < 1e-6
    assert abs(r.ttft_p95_s - 0.18622) < 1e-6


def test_reap_all_backstop():
    from day0.runner import launch_isolated, reap_all, _LIVE_PROCS
    p = launch_isolated(["sleep", "30"])
    assert p in _LIVE_PROCS
    reap_all()
    assert p.poll() is not None


def test_gpus_clean_no_smi_is_permissive():
    from day0.runner import gpus_clean
    ok, detail = gpus_clean()          # no nvidia-smi in this container
    assert ok and "skipping guard" in detail or ok


def test_screen_cap_and_circuit_breaker(tmp_path, monkeypatch):
    from day0 import runner as rn
    from day0.store import Store
    from day0.runner import TrialOutcome, successive_halving
    f, j = facts(), load_job(JOB)
    j.raw.setdefault("budget", {})["screen_cap"] = 6
    cands, _ = search_space.generate(f, j)
    a = [c for c in cands if c.track == "A"]

    def fake_run(c, job, fx, rung, *, simulate):
        if c.dp > 1:
            return TrialOutcome(c, "crash", reason="synthetic dp crash")
        from day0.bench.harness import BenchResult
        r = BenchResult(job.profiles[0].name, 8.0, 10000, 5000, 0.1, 0.2, 12.0,
                        8.0, 5000.0 + c.tp, 1.0)
        return TrialOutcome(c, "ok", per_profile={p.name: r for p in job.profiles},
                            score=5000.0 + c.tp)

    monkeypatch.setattr(rn, "run_trial", fake_run)
    st = Store(tmp_path / "t.sqlite")
    champ = successive_halving("A", a, j, f, st, simulate=True, bayes_iters=0)
    assert champ is not None and champ.status == "ok"
    capped = st.db.execute(
        "SELECT COUNT(*) FROM trials WHERE reason LIKE 'screen cap%'").fetchone()[0]
    assert capped == len(a) - 6
    # breaker: <=2 launches per crashing family; dp>1 spans two families (ep on/off)
    crashed = st.db.execute(
        "SELECT COUNT(*) FROM trials WHERE status='crash' AND rung='screen'").fetchone()[0]
    assert crashed <= 4
    # family-aware cap kept a dp==1 representative, so the track survived
    assert champ.candidate.dp == 1


def test_kb_veto_and_seed_gemma4():
    from day0 import kb as kbmod
    from day0.search_space import Candidate
    cfg = json.loads((ROOT / "configs" / "cached_model_configs" /
                      "google__gemma-4-26B-A4B-it.json").read_text())
    g = introspect("google/gemma-4-26B-A4B-it", config_override=cfg)
    entries = kbmod.load(g)
    assert entries, "gemma-4 KB entry should match"
    bad = Candidate("A", "aggregated", 8, 1, 1, 1, "bf16", "bf16", 8192, 512, 0, "off")
    assert "kb:" in (kbmod.veto(entries, bad) or "")
    good = Candidate("A", "aggregated", 8, 8, 1, 1, "bf16", "bf16", 8192, 512, 0, "off")
    assert kbmod.veto(entries, good) is None
    promoted, why = kbmod.seeds(entries, [bad, good])
    assert good.cid in promoted and any("kb seed" in w for w in why)
    dp = Candidate("A", "aggregated", 1, 8, 8, 1, "bf16", "bf16", 8192, 512, 0, "off")
    assert "view()" in (kbmod.veto(entries, dp) or "")


def test_kb_scopes_to_matching_family():
    from day0 import kb as kbmod
    names = {e.name for e in kbmod.load(facts())}       # DeepSeek facts
    assert "deepseek-v4-family" in names
    assert "gemma-4-family" not in names


def test_kb_learn_draft(tmp_path, monkeypatch):
    from day0 import kb as kbmod
    from day0.store import Store
    monkeypatch.setenv("DAY0_KB", str(tmp_path / "kb"))
    db_path = tmp_path / "runs.sqlite"
    st = Store(db_path)
    st.meta("model_facts", facts().to_dict())
    st.meta("mode", "cluster")
    st.trial(cid="abc", track="A", rung="refine", stage="track", label="x",
             config={"serving_mode": "aggregated", "tp": 8, "ep": 8, "dp": 2,
                     "quant": "fp8", "kv_dtype": "bf16", "chunked_prefill": 8192,
                     "spec_decode": 0, "hicache": "off", "engine": "sglang"},
             status="ok", score=42000.0)
    st.close()
    p = kbmod.draft_from_run(db_path)
    import yaml as _y
    draft = _y.safe_load(p.read_text())
    assert draft["known_good"][0]["evidence"] == "measured"
    assert draft["known_good"][0]["config"]["tp"] == 8
    assert "drafts" in str(p)
