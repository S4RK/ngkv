"""The shared benchmark harness — the non-negotiable.

One version-pinned invocation of sglang.bench_serving for every trial in every
track and stage. Ranking metric is goodput-at-SLO: requests violating TTFT or
TPOT SLOs contribute zero. Prefix-share injection honors the assumed hit rate
so cache-heavy configs are not structurally under-measured.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from ..job import Job, WorkloadProfile

SEED = 1234


def bench_cmd(base_url: str, profile: WorkloadProfile, job: Job,
              *, num_prompts: int, request_rate: float, out: Path) -> list[str]:
    return [
        "python", "-m", "sglang.bench_serving",
        "--backend", "sglang-oai",
        "--base-url", base_url,
        "--dataset-name", "random",
        "--random-input-len", str(profile.isl),
        "--random-output-len", str(profile.osl),
        "--random-range-ratio", "0.5",
        "--num-prompts", str(num_prompts),
        "--request-rate", str(request_rate),
        "--seed", str(SEED),
        "--output-details",              # per-request ttfts/itls/output_lens for exact goodput
        "--output-file", str(out),
    ]


@dataclass
class BenchResult:
    profile: str
    request_rate: float
    input_tps: float             # prefill tokens/s (fleet)
    output_tps: float            # decode tokens/s (fleet)
    ttft_p50_s: float
    ttft_p95_s: float
    tpot_p95_ms: float
    goodput_rps: float           # requests/s meeting both SLOs
    goodput_output_tps: float    # output tok/s from SLO-meeting requests only
    slo_attainment: float        # fraction of requests meeting both SLOs

    def to_dict(self):
        return asdict(self)


def _pct(xs: list, p: float):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, math.ceil(p * len(xs)) - 1)]


def _est_attainment(p50, p90, p95, p99, slo) -> float:
    """Aggregate-only fallback: piecewise-linear attainment estimate from the
    percentile ladder. Marked as an estimate; exact path uses per-request data."""
    pts = [(0.50, p50), (0.90, p90), (0.95, p95), (0.99, p99)]
    pts = [(q, v) for q, v in pts if v is not None]
    if not pts:
        return 0.0
    if slo >= pts[-1][1]:
        return 1.0
    if slo < pts[0][1]:
        return max(0.0, 0.5 * slo / max(pts[0][1], 1e-9))
    for (q1, v1), (q2, v2) in zip(pts, pts[1:]):
        if v1 <= slo <= v2:
            return q1 + (q2 - q1) * (slo - v1) / max(v2 - v1, 1e-9)
    return 0.5


def summarize(raw_jsonl: Path, job: Job, profile: WorkloadProfile,
              request_rate: float) -> BenchResult:
    """Parse sglang.benchmark.serving --output-file records (one aggregate JSON
    line per run; with --output-details it also carries per-request arrays).
    Per-request path computes EXACT goodput-at-SLO; aggregate path estimates it."""
    lines = [l for l in raw_jsonl.read_text().splitlines() if l.strip()]
    if not lines:
        raise ValueError(f"empty benchmark output {raw_jsonl}")
    rec = json.loads(lines[-1])
    dur = max(float(rec.get("duration") or 0.0), 1e-6)
    completed = int(rec.get("completed") or 0)
    in_tps = float(rec.get("input_throughput") or 0.0)
    out_tps = float(rec.get("output_throughput") or 0.0)

    ttfts, itls, outs = rec.get("ttfts"), rec.get("itls"), rec.get("output_lens")
    if ttfts and itls and outs:
        errs = rec.get("errors") or [None] * len(ttfts)
        per_ttft, per_tpot = [], []
        n_ok, ok_out, n = 0, 0, 0
        for t, il, o, e in zip(ttfts, itls, outs, errs):
            if t is None:
                continue
            n += 1
            tpot_ms = 1000.0 * sum(il) / len(il) if il else 0.0
            per_ttft.append(float(t))
            per_tpot.append(tpot_ms)
            if not e and t <= job.slo_ttft_p95_s and tpot_ms <= job.slo_tpot_p95_ms:
                n_ok += 1
                ok_out += int(o or 0)
        if n == 0:
            raise ValueError("benchmark record has details but zero measured requests")
        return BenchResult(
            profile=profile.name, request_rate=request_rate,
            input_tps=in_tps, output_tps=out_tps,
            ttft_p50_s=_pct(per_ttft, 0.50), ttft_p95_s=_pct(per_ttft, 0.95),
            tpot_p95_ms=_pct(per_tpot, 0.95),
            goodput_rps=n_ok / dur, goodput_output_tps=ok_out / dur,
            slo_attainment=n_ok / n,
        )

    # aggregate-only fallback (older bench_serving without --output-details)
    a_ttft = _est_attainment(rec.get("median_ttft_ms"), rec.get("p90_ttft_ms"),
                             rec.get("p95_ttft_ms"), rec.get("p99_ttft_ms"),
                             job.slo_ttft_p95_s * 1000.0)
    a_tpot = _est_attainment(rec.get("median_tpot_ms"), rec.get("p90_tpot_ms"),
                             rec.get("p95_tpot_ms"), rec.get("p99_tpot_ms"),
                             job.slo_tpot_p95_ms)
    attain = a_ttft * a_tpot
    return BenchResult(
        profile=profile.name, request_rate=request_rate,
        input_tps=in_tps, output_tps=out_tps,
        ttft_p50_s=float(rec.get("median_ttft_ms") or 0.0) / 1000.0,
        ttft_p95_s=float(rec.get("p95_ttft_ms") or 0.0) / 1000.0,
        tpot_p95_ms=float(rec.get("p95_tpot_ms") or 0.0),
        goodput_rps=completed / dur * attain,
        goodput_output_tps=out_tps * attain,
        slo_attainment=attain,
    )


def mixed_goodput(results: dict[str, BenchResult], job: Job) -> float:
    """Weighted goodput across the workload mix — THE ranking scalar."""
    w = {p.name: p.weight for p in job.profiles}
    return sum(r.goodput_output_tps * w[name] for name, r in results.items())
