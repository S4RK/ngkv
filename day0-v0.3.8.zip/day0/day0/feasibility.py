"""Stage 1 — feasibility pruning by arithmetic, before any GPU is touched.

Rule: weight_mem + kv_budget + activation_headroom <= usable HBM, plus
interconnect sanity for MoE all-to-all and PD KV transfer. Candidates that
fail are recorded with a reason (they feed the 'what didn't work' report
section), never silently dropped.
"""
from __future__ import annotations

from dataclasses import dataclass
from .introspect import ModelFacts
from .job import Job, GPU_SPECS

BYTES_PER_PARAM = {"bf16": 2.0, "fp8": 1.0, "fp4": 0.5}
KV_DTYPE_SCALE = {"bf16": 1.0, "fp8": 0.5, "fp4": 0.25}
USABLE_HBM_FRACTION = 0.92
SGLANG_ACT_VEC_WIDTH = 16   # sglang jit activation kernel (empirical, gemma-4 on 0.5.17)
ACTIVATION_HEADROOM_GB = 12.0  # per GPU, conservative for large-batch CUDA graphs


@dataclass
class Verdict:
    ok: bool
    reason: str
    weight_gb_per_gpu: float = 0.0
    kv_gb_per_gpu: float = 0.0
    kv_tokens_capacity: int = 0  # fleet-wide KV token capacity at this config


def check(facts: ModelFacts, job: Job, *, tp: int, ep: int, pp: int,
          dp: int, quant: str, kv_dtype: str,
          min_kv_tokens: int = 2_000_000, engine: str = "sglang") -> Verdict:
    """Feasibility of one (parallelism, quant) point on the given hardware."""
    world = tp * pp * dp
    if world > job.total_gpus:
        return Verdict(False, f"world size {world} > {job.total_gpus} GPUs")
    if job.total_gpus % world != 0:
        return Verdict(False, f"world size {world} does not divide {job.total_gpus} GPUs")
    if facts.is_moe and ep > facts.n_experts:
        return Verdict(False, f"EP{ep} > {facts.n_experts} experts")
    if facts.is_moe and ep > 1 and (tp * dp) % ep != 0 and ep % (tp * dp) != 0:
        return Verdict(False, f"EP{ep} incompatible with TP{tp}xDP{dp} layout")
    if not facts.is_moe and ep > 1:
        return Verdict(False, "EP on a dense model")
    if quant == "fp4" and facts.native_dtype == "bf16":
        # fp4 without a published variant: v0 does not quantize models itself
        return Verdict(False, "no FP4 checkpoint variant available (flagged as gap)")
    if tp > job.gpus_per_node:
        return Verdict(False, f"TP{tp} crosses node boundary over {job.inter_node}: "
                              "all-reduce per layer over inter-node fabric "
                              "(pruned by policy; use PP or DP across nodes)")

    # --- SGLang JIT activation vector-width rule (small-FFN models, e.g. Gemma 4) ---
    if engine == "sglang":
        ffn_tp = tp * dp                      # SGLang: FFN is TP-sharded across the full world
        v = SGLANG_ACT_VEC_WIDTH
        if facts.is_moe and facts.moe_intermediate_size:
            tp_per_exp = ffn_tp // ep if (ep and ffn_tp % ep == 0) else ffn_tp
            w = facts.moe_intermediate_size
            if w % tp_per_exp or (w // tp_per_exp) % v:
                return Verdict(False,
                               f"expert FFN slice {w}/{tp_per_exp}={w // max(tp_per_exp,1)} "
                               f"not divisible by {v} (sglang jit activation vector width); "
                               f"use EP={ffn_tp} to keep experts whole")
        has_dense_ffn = (not facts.is_moe) or facts.first_k_dense > 0
        if has_dense_ffn and facts.intermediate_size:
            w = facts.intermediate_size
            if w % ffn_tp or (w // ffn_tp) % v:
                return Verdict(False,
                               f"dense FFN slice {w}/{ffn_tp} not divisible by {v} "
                               "(sglang jit activation vector width)")

    # --- memory arithmetic (per GPU) ---
    wb = BYTES_PER_PARAM[quant]
    # dense weights shard over tp*pp; expert weights shard over ep when EP is on,
    # else they are TP-sharded (SGLang default without --enable-ep-moe)
    if facts.is_moe:
        expert_frac = 1.0 - facts.active_params_b / facts.total_params_b  # rough split
        dense_gb = facts.total_params_b * (1 - expert_frac) * wb / (tp * pp)
        expert_shard = (ep if ep > 1 else tp) * pp
        expert_gb = facts.total_params_b * expert_frac * wb / expert_shard
        weight_gb = dense_gb + expert_gb
    else:
        weight_gb = facts.total_params_b * wb / (tp * pp)

    usable = job.hbm_gb_per_gpu * USABLE_HBM_FRACTION
    kv_budget_gb = usable - weight_gb - ACTIVATION_HEADROOM_GB
    if kv_budget_gb <= 0:
        return Verdict(False,
                       f"OOM by arithmetic: weights {weight_gb:.0f}GB + "
                       f"headroom {ACTIVATION_HEADROOM_GB:.0f}GB > usable {usable:.0f}GB",
                       weight_gb_per_gpu=weight_gb)

    kv_bytes_tok = facts.kv_bytes_per_token_bf16 * KV_DTYPE_SCALE[kv_dtype]
    # KV shards across tp (per KV head / latent split) and pp (layer split);
    # MLA latent KV is replicated across TP in common impls -> shard only by pp.
    kv_shard = pp if facts.attention_type == "mla" else tp * pp
    kv_tokens_per_gpu = kv_budget_gb * 1e9 / (kv_bytes_tok / kv_shard)
    replicas = job.total_gpus // world
    # TP ranks replicate MLA KV; DP ranks and replica groups hold independent caches
    fleet_kv_tokens = int(kv_tokens_per_gpu * dp * replicas)
    if fleet_kv_tokens < min_kv_tokens:
        return Verdict(False,
                       f"KV capacity {fleet_kv_tokens/1e6:.1f}M tokens < "
                       f"{min_kv_tokens/1e6:.0f}M floor (weights {weight_gb:.0f}GB/GPU)",
                       weight_gb_per_gpu=weight_gb, kv_gb_per_gpu=kv_budget_gb,
                       kv_tokens_capacity=fleet_kv_tokens)

    # --- interconnect note: EP crossing EFA is allowed but measured, not pruned;
    # the harness/sim decides whether the all-to-all tax kills it.
    return Verdict(True, "ok", weight_gb_per_gpu=round(weight_gb, 1),
                   kv_gb_per_gpu=round(kv_budget_gb, 1),
                   kv_tokens_capacity=fleet_kv_tokens)
