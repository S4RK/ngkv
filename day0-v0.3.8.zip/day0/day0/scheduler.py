"""v0.2 — resource-aware track scheduler.

CN-02 §8: Tracks A/B need the full pool; C/D fit on one node. The scheduler
runs tracks concurrently, gating each trial on the number of nodes it needs,
so single-node tracks fill the gaps between full-pool slots. Wall-clock budget
is allocated 60% screen/halve, 25% refine, 15% head-to-head+gate; if a phase
projects over budget the rate ladder is shortened (never the harness itself)
and the decision is logged.

In simulate mode trials are instant but the same scheduling and budget logic
executes and is recorded — so the schedule is testable in CI.
"""
from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from dataclasses import dataclass

from .job import Job
from .search_space import Candidate
from .runner import RUNG_BUDGET_S

PHASE_SPLIT = {"search": 0.60, "refine": 0.25, "head2head": 0.15}


class NodePool:
    def __init__(self, n_nodes: int):
        self.free: set[int] = set(range(n_nodes))
        self._cv = threading.Condition()

    @contextmanager
    def acquire(self, n: int):
        with self._cv:
            self._cv.wait_for(lambda: len(self.free) >= n)
            nodes = sorted(self.free)[:n]
            self.free -= set(nodes)
        try:
            yield nodes
        finally:
            with self._cv:
                self.free |= set(nodes)
                self._cv.notify_all()


def nodes_needed(c: Candidate, job: Job) -> int:
    if c.serving_mode == "pd_disagg" and c.pd_split.endswith("node"):
        return 2
    world = c.tp * c.pp * c.dp
    return max(1, -(-world // job.gpus_per_node))  # ceil


@dataclass
class Budget:
    """Per-phase wall-clock accounting; shortens rate ladders when over."""
    total_s: float
    spent: dict[str, float]
    lock: threading.Lock

    @classmethod
    def from_job(cls, job: Job) -> "Budget":
        return cls(job.wall_clock_h * 3600, {p: 0.0 for p in PHASE_SPLIT},
                   threading.Lock())

    def phase_cap(self, phase: str) -> float:
        return self.total_s * PHASE_SPLIT[phase]

    def charge(self, phase: str, seconds: float) -> None:
        with self.lock:
            self.spent[phase] += seconds

    def ladder_factor(self, phase: str, projected_s: float) -> float:
        """Returns fraction of the rate ladder to keep (1.0 = full)."""
        with self.lock:
            remaining = self.phase_cap(phase) - self.spent[phase]
        if projected_s <= remaining or projected_s <= 0:
            return 1.0
        return max(0.34, remaining / projected_s)   # never below ~1/3 of ladder


def run_tracks(by_track: dict[str, list[Candidate]], job: Job, facts, store,
               *, simulate: bool, halving_fn) -> dict:
    """Run all tracks concurrently under the node pool + budget.

    halving_fn(track, cands, job, facts, store, simulate, pool, budget) — the
    runner's successive_halving, now pool/budget-aware.
    """
    pool = NodePool(job.nodes)
    budget = Budget.from_job(job)
    champions = {}
    with ThreadPoolExecutor(max_workers=len(by_track)) as ex:
        futs = {ex.submit(halving_fn, t, cands, job, facts, store,
                          simulate=simulate, pool=pool, budget=budget): t
                for t, cands in sorted(by_track.items())}
        for f, t in futs.items():
            try:
                champ = f.result()
            except Exception as e:  # noqa: BLE001 — a track must never kill the run
                store.decide("scheduler", f"track {t}",
                             f"ABORTED by exception: {type(e).__name__}: {e}")
                continue
            if champ:
                champions[t] = champ
    store.decide("scheduler", "budget",
                 "; ".join(f"{p}: {s:.0f}s/{budget.phase_cap(p):.0f}s"
                           for p, s in budget.spent.items()))
    return champions
