"""Stage 2–3 executor: per-track successive halving, then head-to-head.

Execution backends:
  simulate=True  -> analytical model (sim.py), deterministic, no GPUs.
  simulate=False -> launches SGLang (engines/sglang.py) and runs the shared
                    harness (bench/harness.py) on the cluster. The command
                    plumbing is identical; only the measurement source differs.
"""
from __future__ import annotations

import os
import signal
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from .introspect import ModelFacts
from .job import Job
from .search_space import Candidate
from .bench.harness import BenchResult, mixed_goodput, bench_cmd, summarize
from .engines.sglang import launch_cmd, wait_healthy
from . import sim
from .store import Store

RUNG_BUDGET_S = {"screen": 180, "halve": 600, "refine": 1800, "head2head": 1800}


_LIVE_PROCS: set = set()


def launch_isolated(cmd) -> subprocess.Popen:
    """Engines run in their OWN session/process group. SGLang's failure handler
    kills its process group on scheduler death; without isolation that group is
    day0's, and one bad candidate takes down the whole run. Every launch is
    registered so reap_all() can clean up if day0 itself dies (Ctrl-C, SIGTERM):
    isolated sessions do NOT receive the terminal's SIGINT, so without this an
    interrupted run orphans a GPU-holding engine."""
    p = subprocess.Popen(cmd, start_new_session=True)  # noqa: S603
    _LIVE_PROCS.add(p)
    return p


def reap_all() -> None:
    """Backstop teardown for any engine still alive; wired to atexit/SIGTERM."""
    for p in list(_LIVE_PROCS):
        try:
            kill_tree(p, grace_s=10)
        except Exception:  # noqa: BLE001 — best-effort during interpreter exit
            pass


def gpus_clean(max_used_mib: int = 4096) -> tuple[bool, str]:
    """True when no GPU has significant memory held before we start launching."""
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=memory.used",  # noqa: S603
                            "--format=csv,noheader,nounits"],
                           capture_output=True, text=True, timeout=15)
        used = [int(x) for x in r.stdout.split() if x.strip().isdigit()]
    except Exception as e:  # noqa: BLE001
        return True, f"nvidia-smi unavailable ({type(e).__name__}); skipping guard"
    dirty = [f"GPU{i}:{u}MiB" for i, u in enumerate(used) if u > max_used_mib]
    if dirty:
        return False, ("GPUs occupied before launch: " + ", ".join(dirty)
                       + " — orphaned engines? Run: pkill -9 -f sglang; "
                         "verify nvidia-smi shows ~0 MiB, then retry.")
    return True, "clean"


def kill_tree(proc: subprocess.Popen, grace_s: int = 60) -> None:
    """Group-kill: with start_new_session, pgid == engine pid, so this reaps
    scheduler children too (they otherwise orphan and hold GPU memory)."""
    for sig, timeout in ((signal.SIGTERM, grace_s), (signal.SIGKILL, 10)):
        try:
            os.killpg(proc.pid, sig)
        except ProcessLookupError:
            return
        try:
            proc.wait(timeout=timeout)
            return
        except subprocess.TimeoutExpired:
            continue


@dataclass
class TrialOutcome:
    candidate: Candidate
    status: str                      # ok | crash | slo_infeasible
    reason: str = ""
    per_profile: dict[str, BenchResult] = field(default_factory=dict)
    score: float | None = None       # mixed goodput at SLO


def _rate_ladder(job: Job, rung: str) -> list[float]:
    # sweep request rate to saturation; screen uses two points, refine the full ladder
    base = [4.0, 8.0, 16.0, 32.0, 64.0, 128.0]
    return base[1:3] if rung == "screen" else (base[:4] if rung == "halve" else base)


def run_trial(c: Candidate, job: Job, facts: ModelFacts, rung: str,
              *, simulate: bool) -> TrialOutcome:
    profiles = job.profiles if rung != "screen" else job.profiles[:1]

    if simulate:
        import random as _r
        if _r.Random(c.cid).random() < sim.crash_probability(c):
            return TrialOutcome(c, "crash",
                                reason=_classify_sim_crash(c))
        best_per_profile: dict[str, BenchResult] = {}
        for p in profiles:
            best = None
            for rate in _rate_ladder(job, rung):
                r = sim.simulate(c, job, facts, p, rate)
                if best is None or r.goodput_output_tps > best.goodput_output_tps:
                    best = r
            best_per_profile[p.name] = best
    else:
        real = _run_real(c, job, rung, profiles)
        if isinstance(real, tuple):                       # ("crash", reason)
            return TrialOutcome(c, real[0], reason=real[1])
        best_per_profile = real

    if rung == "screen":
        score = best_per_profile[profiles[0].name].goodput_output_tps
    else:
        score = mixed_goodput(best_per_profile, job)
    if score <= 0:
        return TrialOutcome(c, "slo_infeasible",
                            reason="zero goodput at every rate on the ladder",
                            per_profile=best_per_profile, score=0.0)
    return TrialOutcome(c, "ok", per_profile=best_per_profile, score=score)


def _run_real(c: Candidate, job: Job, rung: str, profiles):
    """Cluster mode: dispatch by engine + serving mode. PD candidates are
    supervised as a prefill+decode+router trio (v0.2)."""
    if c.serving_mode == "pd_disagg":
        from .engines.pd_orchestrator import PDDeployment
        with PDDeployment(c, job) as dep:
            if dep.failure:
                return ("crash", f"PD orchestration: {dep.failure}")
            return _bench_endpoint(dep.base_url, c, job, rung, profiles)
    if c.engine == "trtllm":
        from .engines import trtllm
        cmd, base = trtllm.launch_cmd(c, job), "http://127.0.0.1:30000"
    else:
        cmd, base = launch_cmd(c, job), "http://127.0.0.1:30000"
    try:
        proc = launch_isolated(cmd)
    except FileNotFoundError:
        return ("crash", f"{c.engine}: binary '{cmd[0]}' not found on this node")
    try:
        if not wait_healthy(base, proc=proc):
            return ("crash", f"{c.engine} engine failed health check (see logs)")
        return _bench_endpoint(base, c, job, rung, profiles)
    finally:
        kill_tree(proc)
        _LIVE_PROCS.discard(proc)


def _bench_endpoint(base: str, c: Candidate, job: Job, rung: str, profiles):
    out: dict[str, BenchResult] = {}
    for p in profiles:
        best = None
        for rate in _rate_ladder(job, rung):
            with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
                raw = Path(f.name)
            n = max(64, int(rate * RUNG_BUDGET_S[rung] / len(profiles)))
            try:
                subprocess.run(bench_cmd(base, p, job, num_prompts=n,  # noqa: S603
                                         request_rate=rate, out=raw),
                               check=True, timeout=RUNG_BUDGET_S[rung] * 3)
                r = summarize(raw, job, p, rate)
            except Exception as e:  # noqa: BLE001 — parse/bench surprises classify, never abort
                return ("crash", f"benchmark failed at {p.name}@{rate}rps: "
                                 f"{type(e).__name__}: {str(e)[:120]}")
            if best is None or r.goodput_output_tps > best.goodput_output_tps:
                best = r
        out[p.name] = best
    return out


def _classify_sim_crash(c: Candidate) -> str:
    if c.spec_decode >= 4:
        return "spec-decode k>=4: draft/verify divergence, engine assertion (sim)"
    if c.kv_dtype == "fp8" and c.hicache == "l3":
        return "fp8-KV x hicache-l3 storage backend: unsupported kernel path at this engine version (sim)"
    return "launch failure under high concurrency with tiny prefill chunks (sim)"


def successive_halving(track: str, cands: list[Candidate], job: Job,
                       facts: ModelFacts, store: Store, *, simulate: bool,
                       pool=None, budget=None, bayes_iters: int = 8
                       ) -> TrialOutcome | None:
    """screen -> halve -> Bayesian refine (v0.3), pool/budget-aware (v0.2).

    pool: scheduler.NodePool or None (None = run unscheduled, e.g. tests).
    budget: scheduler.Budget or None. Ladder shortening from the budget is
    applied per rung and logged; the harness itself is never modified.
    """
    from contextlib import nullcontext

    def _slot(c: Candidate):
        if pool is None:
            return nullcontext([0])
        from .scheduler import nodes_needed
        return pool.acquire(nodes_needed(c, job))

    def _run(c: Candidate, rung: str, phase: str) -> TrialOutcome:
        est = RUNG_BUDGET_S[rung]
        if budget is not None:
            factor = budget.ladder_factor(phase, est)
            if factor < 1.0:
                store.decide("budget", f"{track}:{rung}",
                             f"ladder shortened to {factor:.0%} for {c.cid}")
            budget.charge(phase, est * factor)
        with _slot(c):
            return run_trial(c, job, facts, rung, simulate=simulate)

    def _record(c: Candidate, o: TrialOutcome, rung: str, stage: str = "track"):
        store.trial(cid=c.cid, track=track, rung=rung, stage=stage,
                    label=c.label(), config=c.__dict__ | {"cid": c.cid},
                    status=o.status, reason=o.reason, score=o.score,
                    results={k: v.to_dict() for k, v in o.per_profile.items()} or None)

    # ---- rungs 1-2: screen, halve ----
    pool_cands = list(cands)
    cap = int(job.raw.get("budget", {}).get("screen_cap", 12))

    def _fam(c: Candidate) -> tuple:
        return (c.engine, c.serving_mode, c.dp > 1, c.ep > 1)

    if len(pool_cands) > cap:
        # round-robin across structural families so the cap can never sample
        # away an entire family (one crashing family must not doom the track)
        groups: dict[tuple, list] = {}
        for c in pool_cands:
            groups.setdefault(_fam(c), []).append(c)
        kept, gi = [], 0
        lists = list(groups.values())
        while len(kept) < cap and any(lists):
            if lists[gi % len(lists)]:
                kept.append(lists[gi % len(lists)].pop(0))
            gi += 1
            if all(not l for l in lists):
                break
        kept_set = {c.cid for c in kept}
        for c in pool_cands:
            if c.cid not in kept_set:
                store.trial(cid=c.cid, track=track, rung="screen", stage="track",
                            label=c.label(), config=c.__dict__ | {"cid": c.cid},
                            status="pruned",
                            reason=f"screen cap {cap}: family round-robin sampled out "
                                   "(raise budget.screen_cap to include)")
        store.decide("track", f"{track}:screen",
                     f"screen cap: {len(pool_cands)} -> {len(kept)} candidates "
                     f"across {len(groups)} families")
        pool_cands = kept
    survivors: list[TrialOutcome] = []
    for rung, keep in (("screen", 0.25), ("halve", 3)):
        outcomes = []
        crash_fams: dict[tuple, int] = {}

        for c in pool_cands:
            if rung == "screen" and crash_fams.get(_fam(c), 0) >= 2:
                store.trial(cid=c.cid, track=track, rung=rung, stage="track",
                            label=c.label(), config=c.__dict__ | {"cid": c.cid},
                            status="skipped_family",
                            reason=f"circuit breaker: 2+ crashes in family {_fam(c)} "
                                   "this rung; sibling skipped to save launches")
                continue
            o = _run(c, rung, "search")
            _record(c, o, rung)
            if o.status == "crash" and rung == "screen":
                crash_fams[_fam(c)] = crash_fams.get(_fam(c), 0) + 1
            outcomes.append(o)
        ok = sorted([o for o in outcomes if o.status == "ok"], key=lambda o: -o.score)
        if not ok:
            store.decide("track", f"{track}:{rung}", "no survivors; track dead")
            return None
        n_keep = max(1, int(len(ok) * keep)) if isinstance(keep, float) else min(keep, len(ok))
        pool_cands = [o.candidate for o in ok[:n_keep]]
        survivors = ok[:n_keep]
        store.decide("track", f"{track}:{rung}",
                     f"{len(outcomes)} tried, {len(ok)} ok, kept {n_keep}; "
                     f"best={survivors[0].candidate.label()} @ {survivors[0].score:.0f} tok/s goodput")

    # ---- rung 3: Bayesian refine (TPE) around the halve champion ----
    from . import bayes
    import random as _random
    champ = survivors[0]
    base = champ.candidate
    space = bayes.refine_space(base, mtp=facts.has_mtp_head)
    rng = _random.Random(int(base.cid, 16) & 0xFFFFFFFF)
    history: list[tuple[dict, float]] = [
        ({a: getattr(o.candidate, a) for a in space}, o.score) for o in survivors]
    best = champ
    for i in range(bayes_iters):
        axes = bayes.tpe_suggest(history, space, rng)
        cand = bayes.apply_axes(base, axes)
        v = feasibility_recheck(cand, job, facts)
        if v is not None:
            store.trial(cid=cand.cid, track=track, rung="refine", stage="track",
                        label=cand.label(), config=cand.__dict__ | {"cid": cand.cid},
                        status="pruned", reason=v)
            history.append((axes, 0.0))
            continue
        o = _run(cand, "refine", "refine")
        _record(cand, o, "refine")
        history.append((axes, o.score or 0.0))
        if o.status == "ok" and (best.score is None or o.score > best.score):
            best = o
    store.decide("track", f"{track}:refine",
                 f"TPE {bayes_iters} iters; best={best.candidate.label()} "
                 f"@ {best.score:.0f} tok/s goodput "
                 f"({'improved on' if best is not champ else 'confirmed'} halve champion)")
    return best


def feasibility_recheck(c: Candidate, job: Job, facts: ModelFacts) -> str | None:
    """Refine may change kv_dtype: re-run the arithmetic. Returns reason or None."""
    from . import feasibility
    v = feasibility.check(facts, job, tp=c.tp, ep=c.ep, pp=c.pp, dp=c.dp,
                          quant=c.quant, kv_dtype=c.kv_dtype, engine=c.engine)
    return None if v.ok else v.reason


def head_to_head(champions: dict[str, TrialOutcome], job: Job, facts: ModelFacts,
                 store: Store, *, simulate: bool) -> list[tuple[str, TrialOutcome]]:
    """Interleaved A,B,C,D,A,B,C,D full-mix runs; only table allowed to rank across tracks."""
    finals: dict[str, list[TrialOutcome]] = {t: [] for t in champions}
    for _round in range(2):
        for t, champ in champions.items():
            o = run_trial(champ.candidate, job, facts, "head2head", simulate=simulate)
            finals[t].append(o)
            store.trial(cid=champ.candidate.cid, track=t, rung="head2head",
                        stage="stage3", label=champ.candidate.label(),
                        config=champ.candidate.__dict__ | {"cid": champ.candidate.cid},
                        status=o.status, reason=o.reason, score=o.score,
                        results={k: v.to_dict() for k, v in o.per_profile.items()} or None)
    ranked = []
    for t, runs in finals.items():
        ok = [o for o in runs if o.status == "ok"]
        if not ok:
            continue
        best = max(ok, key=lambda o: o.score)
        best.score = sum(o.score for o in ok) / len(ok)   # average across rounds
        ranked.append((t, best))
    ranked.sort(key=lambda x: -x[1].score)
    store.decide("stage3", "rank",
                 " > ".join(f"{t}:{o.score:.0f}" for t, o in ranked))
    return ranked
