"""v0.2 — PD disaggregation orchestration.

For pd_disagg candidates, cluster mode must supervise three processes, not
one: a prefill server, a decode server, and the sglang router fronting them.
This module launches all three, health-checks each, exposes a single base_url,
and guarantees teardown (context manager). Failure of any member during
launch classifies the trial as a crash with the member named — feeding the
'what didn't work' section rather than hanging the run.
"""
from __future__ import annotations

import subprocess
import time
from ..search_space import Candidate
from ..job import Job
from .sglang import launch_cmd, wait_healthy

PREFILL_PORT = 30001
DECODE_PORT = 30011
ROUTER_PORT = 30000


def router_cmd(prefill_urls: list[str], decode_urls: list[str],
               *, port: int = ROUTER_PORT) -> list[str]:
    cmd = ["python", "-m", "sglang_router.launch_router",
           "--pd-disaggregation", "--host", "0.0.0.0", "--port", str(port),
           "--policy", "cache_aware"]
    for u in prefill_urls:
        cmd += ["--prefill", u]
    for u in decode_urls:
        cmd += ["--decode", u]
    return cmd


class PDDeployment:
    """launch prefill + decode + router; teardown on exit, always."""

    def __init__(self, c: Candidate, job: Job):
        if c.serving_mode != "pd_disagg":
            raise ValueError("PDDeployment is for pd_disagg candidates only")
        self.c, self.job = c, job
        self.procs: list[tuple[str, subprocess.Popen]] = []
        self.base_url = f"http://127.0.0.1:{ROUTER_PORT}"
        self.failure: str | None = None

    def _spawn(self, name: str, cmd: list[str]):
        from ..runner import launch_isolated
        self.procs.append((name, launch_isolated(cmd)))

    def __enter__(self) -> "PDDeployment":
        c, job = self.c, self.job
        # v0.2 supports the 1P1D-node split (one prefill node, one decode node);
        # gpu-level splits are emitted as commands but flagged unsupervised.
        self._spawn("prefill", launch_cmd(c, job, port=PREFILL_PORT, role="prefill"))
        self._spawn("decode", launch_cmd(c, job, port=DECODE_PORT, role="decode"))
        for name, port in (("prefill", PREFILL_PORT), ("decode", DECODE_PORT)):
            if not wait_healthy(f"http://127.0.0.1:{port}", timeout_s=900):
                self.failure = f"{name} server failed health check"
                self.__exit__(None, None, None)
                return self
        self._spawn("router", router_cmd(
            [f"http://127.0.0.1:{PREFILL_PORT}"],
            [f"http://127.0.0.1:{DECODE_PORT}"]))
        if not wait_healthy(self.base_url, timeout_s=120):
            self.failure = "router failed health check"
            self.__exit__(None, None, None)
        # settle: one KV-transfer path exercise happens on first request;
        # the harness's warmup window covers it.
        time.sleep(2)
        return self

    def __exit__(self, *exc):
        from ..runner import kill_tree
        for name, p in reversed(self.procs):
            try:
                kill_tree(p)
            except Exception:
                pass
        self.procs.clear()
        return False
