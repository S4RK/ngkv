"""v0.2 — `day0 preflight job.yaml`: verify the cluster before burning a night.

Checks are advisory-with-teeth: FAIL blocks a cluster run, WARN doesn't.
Simulate mode never needs preflight.
"""
from __future__ import annotations

import importlib.util
import shutil
import socket
import sys
import subprocess
from dataclasses import dataclass
from pathlib import Path

from .job import Job


@dataclass
class Check:
    name: str
    status: str      # PASS | WARN | FAIL
    detail: str


def _gpu_count() -> tuple[int, str]:
    if shutil.which("nvidia-smi") is None:
        return 0, "nvidia-smi not found"
    r = subprocess.run(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                       capture_output=True, text=True)  # noqa: S603
    names = [l for l in r.stdout.splitlines() if l.strip()]
    return len(names), (names[0] if names else r.stderr.strip()[:200])


def _port_free(port: int) -> bool:
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def run_preflight(job: Job) -> list[Check]:
    checks: list[Check] = []

    n, detail = _gpu_count()
    want = job.gpus_per_node   # preflight runs per node
    checks.append(Check("gpus_visible",
                        "PASS" if n >= want else "FAIL",
                        f"{n} GPUs visible on this node (need {want}); first: {detail}"))

    r = subprocess.run([sys.executable, "-c",
                        "import sglang, sglang.launch_server; print(sglang.__version__)"],
                       capture_output=True, text=True)  # noqa: S603
    ok = r.returncode == 0
    checks.append(Check("sglang_importable", "PASS" if ok else "FAIL",
                        f"sglang {r.stdout.strip()} imports cleanly (launch path verified)"
                        if ok else "sglang launch path failed to import: "
                        + (r.stderr.strip().splitlines() or ["?"])[-1][:180]))

    have_router = importlib.util.find_spec("sglang_router") is not None
    checks.append(Check("sglang_router", "PASS" if have_router else "WARN",
                        "router available (needed for PD track B)" if have_router
                        else "sglang_router missing: Track B will be skipped"))

    nvme = Path(job.local_nvme)
    if nvme.exists():
        stat = shutil.disk_usage(nvme)
        free_tb = stat.free / 1e12
        model_dir = nvme / "models"
        cached = any(model_dir.glob(f"**/{job.model_id.split('/')[-1]}*")) \
            if model_dir.exists() else False
        checks.append(Check("local_nvme", "PASS" if free_tb > 2.0 else "WARN",
                            f"{job.local_nvme}: {free_tb:.1f}TB free; "
                            f"model {'cached' if cached else 'NOT cached — first launch pays the download'}"))
    else:
        checks.append(Check("local_nvme", "FAIL",
                            f"{job.local_nvme} does not exist on this node"))

    for port in (30000, 30001, 30011):
        checks.append(Check(f"port_{port}", "PASS" if _port_free(port) else "FAIL",
                            "free" if _port_free(port) else "in use"))

    efa = Path("/sys/class/infiniband")
    n_efa = len(list(efa.glob("*"))) if efa.exists() else 0
    checks.append(Check("efa_devices",
                        "PASS" if n_efa > 0 or job.nodes == 1 else "WARN",
                        f"{n_efa} RDMA devices visible "
                        f"({'multi-node needs EFA for PD KV transfer' if job.nodes > 1 else 'single node: not required'})"))

    have_agate = shutil.which("agate") is not None
    checks.append(Check("agate", "PASS" if have_agate else "WARN",
                        "accuracy gate available" if have_agate else
                        "agate missing: Stage 4 will be SKIPPED — do not promote to prod without it"))
    return checks


def verdict(checks: list[Check]) -> bool:
    return not any(c.status == "FAIL" for c in checks)
