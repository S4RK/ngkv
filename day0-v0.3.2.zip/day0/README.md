# day0 — grid-search agent for day-0 model deployment

**Give it a HuggingFace model, your hardware, your workload mix, and your SLOs.
Get back the optimal serving configuration — with evidence, and with a record
of everything that *didn't* work.**

Concept note: CN-02. Status: **v0.3.0** — pipeline complete with the v0.2
scheduler + PD orchestration + preflight and the v0.3 Bayesian refinement +
warm-starts + TRT-LLM track. Simulate mode fully functional; first live
validation run pending (`day0 preflight` is the gate for that).

## Quickstart (no GPUs needed)

```bash
pip install -e .
day0 run configs/example-job.yaml --simulate
```

This runs the entire pipeline — introspection → feasibility pruning → 4
optimization tracks with successive halving → head-to-head → accuracy gate →
report — against a deterministic analytical performance model, in under a
second. Open `day0-<digest>/report.md` for the deployment record.

**Every simulated number is labeled as simulated**, in the report header and in
`envelope.json` (`measurement_source: SIMULATED-ANALYTICAL-MODEL`). Simulate
mode exists to demo the workflow, test the ranking logic in CI, and let
stakeholders see the report format — not to make performance claims.

On the cluster, drop `--simulate`: the identical pipeline launches SGLang per
candidate (`day0/engines/sglang.py` builds every launch command
deterministically from the config) and measures with the shared harness.

## The pipeline

```
job.yaml → Stage 0 introspect → Stage 1 feasibility (arithmetic) → Stage 2: 4 tracks
                                                                     A aggregated max-throughput
                                                                     B PD disaggregation
                                                                     C latency / spec decoding
                                                                     D KV / memory / long-context
         → Stage 3 head-to-head (interleaved, full mix) → Stage 4 agate gate → Stage 5 report
```

Design commitments (see CN-02 for rationale):

1. **One harness.** Every trial in every track and stage uses the same
   version-pinned `sglang.bench_serving` invocation with the same seed and
   profiles. Comparability is the product.
2. **Goodput at SLO is the ranking metric.** Requests violating TTFT/TPOT SLOs
   contribute zero. Raw tok/s never crowns a winner.
3. **Arithmetic before GPUs.** Memory and interconnect arithmetic prunes most
   of the grid for free; every pruned candidate is recorded with its reason.
4. **Failures are findings.** The report's "What didn't work" section is
   mandatory and generated from `runs.sqlite` failure classifications.
5. **The gate can demote the winner.** A config that wins throughput but fails
   the agate accuracy gate ships struck-through, not to production. If agate
   is absent the gate is recorded as SKIPPED, never silently passed.
6. **Everything is reproducible.** `runs.sqlite` (WAL) holds every trial's
   config hash, results, and every agent decision with a rationale trace.

## Outputs

| File | What |
|---|---|
| `report.md` | Deployment record: winner, head-to-head, per-profile detail, what didn't work, reproduction block |
| `winner/launch.sh` + `serve.yaml` | Directly runnable launch command for the winning config |
| `envelope.json` | Certified performance envelope in CN-01 topology-catalog format |
| `runs.sqlite` | Every trial + decision, WAL mode |

## Repo map

```
day0/
  job.py           job.yaml schema + hardware table
  introspect.py    Stage 0: config.json → ModelFacts (MLA/GQA detection, MoE, MTP, quant)
  feasibility.py   Stage 1: memory + interconnect arithmetic → prune with reasons
  search_space.py  Stage 2: candidate generation per track
  runner.py        successive halving (screen→halve→refine) + head-to-head
  engines/sglang.py  Candidate → exact SGLang launch command
  bench/harness.py   shared harness wrapper + goodput-at-SLO summarizer
  sim.py           analytical model backing --simulate (labeled, first-order only)
  gate.py          agate hook (pass/fail/SKIPPED — never silent)
  report.py        Stage 5 report + envelope
  store.py         runs.sqlite
configs/example-job.yaml   DeepSeek-V4-class MoE on 2x B200, 4 tracks
tests/                     unit + end-to-end simulate + determinism
```

## v0.2 — scheduler, PD orchestration, preflight

- **Resource-aware scheduler** (`scheduler.py`): all tracks run concurrently
  under a node pool. Tracks C/D use single-node layouts (fleet numbers
  extrapolate by replica count) and fill the gaps between A/B/E full-pool
  slots. Wall-clock budget is split 60/25/15 across search/refine/head-to-head;
  when a phase projects over budget the rate ladder is shortened (never the
  harness) and the decision is logged.
- **PD orchestration** (`engines/pd_orchestrator.py`): pd_disagg trials are
  supervised as a prefill + decode + router trio with per-member health checks
  and guaranteed teardown; a failed member classifies the trial as a crash
  naming the member.
- **Preflight** (`day0 preflight job.yaml`): GPUs visible, sglang + router
  importable, model cached on local NVMe, ports free, EFA devices present,
  agate on PATH. Any FAIL is a NO-GO for a cluster run.

## v0.3 — Bayesian refinement, warm-starts, TRT-LLM

- **TPE refinement** (`bayes.py`, pure stdlib): rung 3 replaces grid
  perturbation with a Tree-structured Parzen Estimator over the knob axes
  (chunk size, batch ceiling, KV dtype, spec k, hicache tier), seeded by the
  halve survivors. Refined configs that change memory-relevant knobs are
  re-checked by the feasibility arithmetic before launch.
- **Cross-model warm-starts** (`priors.py`): completed runs register in
  `$DAY0_REGISTRY` (default `~/.day0/registry`). New runs promote candidates
  matching prior winners of architecturally similar models (attention type,
  MoE-ness, size band, MTP) to the front of the screen rung with a guaranteed
  halve slot — priors order the search; evidence still decides it. Disable
  with `--no-priors`.
- **Track E — TRT-LLM bake-off** (`engines/trtllm.py`): mirrors the strongest
  aggregated layouts onto `trtllm-serve` (PyTorch backend). The harness is
  engine-agnostic, so numbers stay comparable. v0.3 scope: aggregated only,
  no hicache/spec axes (logged as scope, not silently absent).

## Known limits (v0.3)

- First live cluster validation run has not happened yet; simulate-mode
  numbers remain workflow demos, not performance claims.
- PD orchestration supervises the 1P1D-node split; GPU-level splits are
  emitted as commands but unsupervised.
- TRT-LLM track: aggregated serving only; TRT-LLM MTP spec decoding is v0.4.
- The agent still does not quantize models itself (missing FP4 = flagged gap).

## Roadmap

v0.4: live validation on K3 (preflight-gated); TRT-LLM spec decoding; GPU-level
PD splits under supervision; auto-quantization for missing FP4 variants.
