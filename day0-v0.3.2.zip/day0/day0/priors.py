"""v0.3 — cross-model warm-starts.

Every completed run registers (model_facts, winner_config, score) in a
registry (DAY0_REGISTRY env or ~/.day0/registry). A new run scans the
registry, scores architectural similarity, and *promotes* matching candidates:
they run first in the screen rung and are guaranteed a slot in 'halve'
(seeding, never skipping measurement — priors order the search, evidence
still decides it). Every promotion logs a rationale naming its source run.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from .introspect import ModelFacts
from .search_space import Candidate


def registry_dir() -> Path:
    return Path(os.environ.get("DAY0_REGISTRY",
                               str(Path.home() / ".day0" / "registry")))


def record_run(facts: ModelFacts, winner_config: dict, score: float,
               job_digest: str, mode: str) -> Path:
    d = registry_dir()
    d.mkdir(parents=True, exist_ok=True)
    rec = {
        "ts": time.time(), "job_digest": job_digest, "mode": mode,
        "model_facts": facts.to_dict(), "winner": winner_config, "score": score,
    }
    p = d / f"{job_digest}-{int(time.time())}.json"
    p.write_text(json.dumps(rec, indent=2))
    return p


def _similarity(a: dict, b: ModelFacts) -> int:
    s = 0
    s += 3 if a.get("attention_type") == b.attention_type else 0
    s += 2 if bool(a.get("is_moe")) == b.is_moe else 0
    if b.is_moe and a.get("is_moe"):
        ra = a.get("n_experts") or 1
        s += 1 if 0.5 <= ra / max(b.n_experts, 1) <= 2.0 else 0
    ta = a.get("total_params_b") or 0
    s += 1 if ta and 0.4 <= ta / max(b.total_params_b, 1e-9) <= 2.5 else 0
    s += 1 if bool(a.get("has_mtp_head")) == b.has_mtp_head else 0
    return s


def _config_matches(prior: dict, c: Candidate) -> bool:
    keys = ("serving_mode", "quant", "kv_dtype", "hicache")
    if any(prior.get(k) != getattr(c, k) for k in keys):
        return False
    # layout family match: same EP-ness and TP band
    if (prior.get("ep", 1) > 1) != (c.ep > 1):
        return False
    return abs((prior.get("tp") or 1) - c.tp) <= 4


def warm_start(facts: ModelFacts, cands: list[Candidate],
               *, min_similarity: int = 5, exclude_mode: str | None = None
               ) -> tuple[list[Candidate], set[str], list[str]]:
    """Returns (reordered candidates, promoted cids, rationales)."""
    d = registry_dir()
    if not d.exists():
        return cands, set(), []
    priors = []
    for p in sorted(d.glob("*.json"), reverse=True):
        try:
            rec = json.loads(p.read_text())
        except Exception:
            continue
        if exclude_mode and rec.get("mode") == exclude_mode:
            continue
        sim = _similarity(rec.get("model_facts", {}), facts)
        if sim >= min_similarity:
            priors.append((sim, rec, p.name))
    if not priors:
        return cands, set(), []
    priors.sort(key=lambda x: (-x[0], -x[1].get("score", 0)))

    promoted: set[str] = set()
    rationales: list[str] = []
    for sim, rec, src in priors[:5]:
        w = rec.get("winner", {})
        for c in cands:
            if c.cid in promoted or not _config_matches(w, c):
                continue
            promoted.add(c.cid)
            rationales.append(
                f"promoted {c.cid} ({c.label()}): matches winner of {src} "
                f"(similarity {sim}, prior score {rec.get('score', 0):,.0f})")
            break
    ordered = ([c for c in cands if c.cid in promoted]
               + [c for c in cands if c.cid not in promoted])
    return ordered, promoted, rationales
