"""v0.3 — TRT-LLM engine support (Track E: multi-engine bake-off).

Maps a Candidate to a `trtllm-serve` command (PyTorch backend). Track E clones
the strongest aggregated layouts onto the second engine; the shared harness is
engine-agnostic (OpenAI-compatible endpoint), so numbers stay comparable.
v0.3 scope: aggregated serving only; no hicache axis; spec decoding via
TRT-LLM's own MTP path is deferred to v0.4 (kept out of the search space so
absence is a logged scope note, not a silent miss).
"""
from __future__ import annotations

from ..search_space import Candidate
from ..job import Job

PORT = 30000


def launch_cmd(c: Candidate, job: Job, *, port: int = PORT) -> list[str]:
    if c.serving_mode != "aggregated":
        raise ValueError("trtllm engine in v0.3 supports aggregated serving only")
    cmd = [
        "trtllm-serve", job.model_id,
        "--host", "0.0.0.0", "--port", str(port),
        "--backend", "pytorch",
        "--tp_size", str(c.tp),
        "--ep_size", str(max(c.ep, 1)),
        "--max_batch_size", str(c.max_running_reqs),
        "--max_num_tokens", str(c.chunked_prefill),
        "--kv_cache_free_gpu_memory_fraction", "0.90",
        "--trust_remote_code",
    ]
    if c.pp > 1:
        cmd += ["--pp_size", str(c.pp)]
    if c.kv_dtype == "fp8":
        cmd += ["--kv_cache_dtype", "fp8"]
    if job.nodes > 1 and c.tp * c.dp * c.pp > job.gpus_per_node:
        cmd = ["mpirun", "-n", str(job.nodes), "--allow-run-as-root"] + cmd
    return cmd


def health_url(port: int = PORT) -> str:
    return f"http://127.0.0.1:{port}/health"
