"""SGLang launch-command builder + health check.

The agent never hand-edits engine flags per trial; every Candidate maps
deterministically to a launch command here, so runs.sqlite fully reproduces
any trial.
"""
from __future__ import annotations

import time
import urllib.request
from ..search_space import Candidate
from ..job import Job

PORT = 30000


def launch_cmd(c: Candidate, job: Job, *, port: int = PORT, role: str = "") -> list[str]:
    cmd = [
        "python", "-m", "sglang.launch_server",
        "--model-path", job.model_id,
        "--revision", job.model_revision,
        "--host", "0.0.0.0", "--port", str(port),
        "--tp-size", str(c.tp),
        "--dp-size", str(c.dp),
        "--chunked-prefill-size", str(c.chunked_prefill),
        "--max-running-requests", str(c.max_running_reqs),
        "--mem-fraction-static", "0.90",
        "--trust-remote-code",
        "--download-dir", f"{job.local_nvme}/models",
    ]
    if c.ep > 1:
        cmd += ["--ep-size", str(c.ep), "--enable-ep-moe"]
    if c.dp > 1:
        cmd += ["--enable-dp-attention"]
    if c.quant == "fp8":
        cmd += ["--quantization", "fp8"]
    elif c.quant == "fp4":
        cmd += ["--quantization", "modelopt_fp4"]
    if c.kv_dtype != "bf16":
        cmd += ["--kv-cache-dtype", c.kv_dtype]
    if c.spec_decode:
        cmd += ["--speculative-algorithm", "EAGLE",  # MTP path in current SGLang
                "--speculative-num-steps", str(c.spec_decode),
                "--speculative-num-draft-tokens", str(c.spec_decode + 1)]
    if c.hicache in ("l2", "l3"):
        cmd += ["--enable-hierarchical-cache",
                "--hicache-ratio", "2.0"]
        if c.hicache == "l3":
            cmd += ["--hicache-storage-backend", "file",
                    "--hicache-storage-path", f"{job.local_nvme}/hicache-l3"]
    if c.serving_mode == "pd_disagg" and role:
        cmd += ["--disaggregation-mode", role,          # prefill | decode
                "--disaggregation-transfer-backend", "nixl"]
    if job.nodes > 1 and c.serving_mode == "aggregated" and c.tp * c.dp > job.gpus_per_node:
        cmd += ["--nnodes", str(job.nodes), "--dist-init-addr", "$HEAD_ADDR:5000",
                "--node-rank", "$NODE_RANK"]
    return cmd


def wait_healthy(base_url: str, timeout_s: int = 900) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        try:
            with urllib.request.urlopen(f"{base_url}/health", timeout=5) as r:  # noqa: S310
                if r.status == 200:
                    return True
        except Exception:
            pass
        time.sleep(10)
    return False
