"""v0.3 — Bayesian refinement for rung 3 (TPE over discrete axes, pure stdlib).

Replaces grid perturbation: after 'halve', the top survivors seed a
Tree-structured Parzen Estimator loop over the numeric/discrete knobs
(chunked_prefill, max_running_reqs, kv_dtype, spec k, hicache). All axes are
discrete, so the TPE densities are smoothed categorical distributions:

  score(x) = sum_axis log l(x_a) / g(x_a)

with l fit on the top-gamma configs and g on the rest. Candidates are sampled
from l and the argmax by density ratio is evaluated next. With < min_history
observations it falls back to seeded random exploration, so early behavior is
well-defined.
"""
from __future__ import annotations

import math
import random
from dataclasses import replace
from .search_space import Candidate

GAMMA = 0.30
N_SAMPLE = 48
SMOOTH = 1.0
MIN_HISTORY = 4

REFINE_AXES = {
    "chunked_prefill": [2048, 4096, 8192, 16384],
    "max_running_reqs": [128, 256, 384, 512],
    "kv_dtype": ["bf16", "fp8"],
    "spec_decode": [0, 1, 2, 3],
    "hicache": ["off", "l2", "l3"],
}


def _axis_dist(values: list, support: list, smooth: float) -> dict:
    counts = {v: smooth for v in support}
    for v in values:
        if v in counts:
            counts[v] += 1.0
    z = sum(counts.values())
    return {v: c / z for v, c in counts.items()}


def _sample(dist: dict, rng: random.Random):
    r, acc = rng.random(), 0.0
    for v, p in dist.items():
        acc += p
        if r <= acc:
            return v
    return v  # noqa: B023  (last key; float rounding)


def tpe_suggest(history: list[tuple[dict, float]], space: dict[str, list],
                rng: random.Random) -> dict:
    """history: [(axis-dict, score)]; returns next axis-dict to evaluate."""
    tried = {tuple(sorted(h[0].items())) for h in history}
    if len(history) < MIN_HISTORY:
        for _ in range(200):
            x = {a: rng.choice(vs) for a, vs in space.items()}
            if tuple(sorted(x.items())) not in tried:
                return x
        return {a: rng.choice(vs) for a, vs in space.items()}

    ranked = sorted(history, key=lambda h: -h[1])
    n_good = max(2, math.ceil(GAMMA * len(ranked)))
    good, bad = ranked[:n_good], ranked[n_good:] or ranked[n_good - 1:]
    l_dist = {a: _axis_dist([h[0][a] for h in good], vs, SMOOTH)
              for a, vs in space.items()}
    g_dist = {a: _axis_dist([h[0][a] for h in bad], vs, SMOOTH)
              for a, vs in space.items()}

    best_x, best_r = None, -math.inf
    for _ in range(N_SAMPLE):
        x = {a: _sample(l_dist[a], rng) for a in space}
        if tuple(sorted(x.items())) in tried:
            continue
        r = sum(math.log(l_dist[a][x[a]] / g_dist[a][x[a]]) for a in space)
        if r > best_r:
            best_x, best_r = x, r
    return best_x or {a: rng.choice(vs) for a, vs in space.items()}


def apply_axes(c: Candidate, axes: dict) -> Candidate:
    """New candidate = champion's layout + suggested knob values."""
    fields = {k: v for k, v in axes.items() if k in REFINE_AXES}
    # spec decode only where the model supports it (caller filters the space)
    return replace(c, **fields, meta=dict(c.meta))


def refine_space(c: Candidate, *, mtp: bool, allow_hicache_l3: bool = True) -> dict:
    space = {k: list(v) for k, v in REFINE_AXES.items()}
    if not mtp or c.serving_mode == "pd_disagg":
        space["spec_decode"] = [0]
    if c.engine != "sglang":
        space["hicache"] = ["off"]        # TRT-LLM: no hicache axis in v0.3
        space["spec_decode"] = [0]
    if not allow_hicache_l3:
        space["hicache"] = [v for v in space["hicache"] if v != "l3"]
    return space
