"""Job spec: the single YAML input that fully determines a day0 run."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

GPU_SPECS = {
    # name: (hbm_gb, fp8_tflops_dense, mem_bw_tbps, nvlink_gbps_per_gpu)
    "B200": (180, 4500, 8.0, 1800),
    "H200": (141, 1979, 4.8, 900),
    "H100": (80, 1979, 3.35, 900),
}


@dataclass
class WorkloadProfile:
    name: str
    isl: int
    osl: int
    weight: float


@dataclass
class Job:
    raw: dict[str, Any]
    model_id: str
    model_revision: str
    nodes: int
    gpu: str
    gpus_per_node: int
    inter_node: str
    local_nvme: str
    profiles: list[WorkloadProfile]
    prefix_hit_rate: float
    slo_ttft_p95_s: float
    slo_tpot_p95_ms: float
    reference_goal_input_tps_per_node: int | None
    wall_clock_h: float
    tracks: list[str] = field(default_factory=lambda: ["A", "B", "C", "D"])

    @property
    def total_gpus(self) -> int:
        return self.nodes * self.gpus_per_node

    @property
    def hbm_gb_per_gpu(self) -> float:
        return GPU_SPECS[self.gpu][0]

    def digest(self) -> str:
        return hashlib.sha256(
            json.dumps(self.raw, sort_keys=True).encode()
        ).hexdigest()[:12]


def load_job(path: str | Path) -> Job:
    raw = yaml.safe_load(Path(path).read_text())
    m, h, w, t = raw["model"], raw["hardware"], raw["workload"], raw["targets"]
    if h["gpu"] not in GPU_SPECS:
        raise ValueError(f"unknown gpu {h['gpu']!r}; known: {sorted(GPU_SPECS)}")
    profiles = [WorkloadProfile(p["name"], int(p["isl"]), int(p["osl"]), float(p["weight"]))
                for p in w["profiles"]]
    s = sum(p.weight for p in profiles)
    if abs(s - 1.0) > 1e-6:
        raise ValueError(f"profile weights must sum to 1.0 (got {s})")
    return Job(
        raw=raw,
        model_id=m["hf_id"],
        model_revision=m.get("revision", "main"),
        nodes=int(h["nodes"]),
        gpu=h["gpu"],
        gpus_per_node=int(h.get("gpus_per_node", 8)),
        inter_node=h.get("inter_node", "efa"),
        local_nvme=h.get("local_nvme", "/mnt/local-nvme"),
        profiles=profiles,
        prefix_hit_rate=float(w.get("prefix_hit_rate_assumed", 0.0)),
        slo_ttft_p95_s=float(t["slo"]["ttft_p95_s"]),
        slo_tpot_p95_ms=float(t["slo"]["tpot_p95_ms"]),
        reference_goal_input_tps_per_node=t.get("reference_goal"),
        wall_clock_h=float(raw.get("budget", {}).get("wall_clock_h", 14)),
        tracks=list(raw.get("budget", {}).get("tracks", ["A", "B", "C", "D"])),
    )
