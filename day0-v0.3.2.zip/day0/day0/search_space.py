"""Stage 2 search space — candidates per track, pruned by feasibility.

A Candidate is a fully-specified serving config. Tracks are hypotheses about
where the optimum lives; each owns an axis family but everything is measured
with the same harness.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from dataclasses import dataclass, field, asdict
from .introspect import ModelFacts
from .job import Job
from . import feasibility


@dataclass
class Candidate:
    track: str
    serving_mode: str            # aggregated | pd_disagg
    tp: int
    ep: int
    dp: int
    pp: int
    quant: str                   # bf16 | fp8 | fp4
    kv_dtype: str                # bf16 | fp8 | fp4
    chunked_prefill: int         # tokens
    max_running_reqs: int
    spec_decode: int             # 0=off else draft length k
    hicache: str                 # off | l2 | l3
    engine: str = "sglang"       # sglang | trtllm
    pd_split: str = ""           # e.g. "1P1D-node" | "12P4D-gpu" (pd_disagg only)
    meta: dict = field(default_factory=dict)

    @property
    def cid(self) -> str:
        d = asdict(self)
        d.pop("meta", None)      # meta is annotation, not identity
        return hashlib.sha256(json.dumps(d, sort_keys=True)
                              .encode()).hexdigest()[:10]

    def label(self) -> str:
        core = f"{self.serving_mode}:TP{self.tp}xEP{self.ep}xDP{self.dp}xPP{self.pp}:{self.quant}"
        bits = [core, f"kv={self.kv_dtype}", f"cp={self.chunked_prefill}"]
        if self.engine != "sglang":
            bits.insert(0, f"[{self.engine}]")
        if self.spec_decode:
            bits.append(f"spec=k{self.spec_decode}")
        if self.hicache != "off":
            bits.append(f"hicache={self.hicache}")
        if self.pd_split:
            bits.append(self.pd_split)
        return " ".join(bits)


def _quants(facts: ModelFacts) -> list[str]:
    q = ["fp8"] if facts.native_dtype in ("fp8", "fp4") else ["bf16"]
    if facts.native_dtype == "fp4":
        q.append("fp4")
    return q


def generate(facts: ModelFacts, job: Job) -> tuple[list[Candidate], list[tuple[Candidate, str]]]:
    """Returns (feasible, rejected_with_reason)."""
    feasible: list[Candidate] = []
    rejected: list[tuple[Candidate, str]] = []
    gpn, total = job.gpus_per_node, job.total_gpus
    quants = _quants(facts)

    def consider(c: Candidate):
        v = feasibility.check(facts, job, tp=c.tp, ep=c.ep, pp=c.pp, dp=c.dp,
                              quant=c.quant, kv_dtype=c.kv_dtype)
        if v.ok:
            c.meta.update(weight_gb=v.weight_gb_per_gpu, kv_gb=v.kv_gb_per_gpu,
                          kv_tokens=v.kv_tokens_capacity)
            feasible.append(c)
        else:
            rejected.append((c, v.reason))

    # Parallelism layouts that fit intra-node TP (TP crossing nodes is pruned by policy)
    tp_opts = [t for t in (1, 2, 4, 8) if t <= gpn]
    ep_opts = [1, 2, 4, 8, 16] if facts.is_moe else [1]

    # ---- Track A: aggregated max-throughput ----
    if "A" in job.tracks:
        for tp, ep, quant, cp in itertools.product(tp_opts, ep_opts, quants,
                                                   (2048, 4096, 8192, 16384)):
            for dp in (1, 2, total // tp if tp else 1):
                world = tp * dp
                if world != total and world != gpn:
                    continue
                if ep > world:
                    continue
                consider(Candidate("A", "aggregated", tp, ep, dp, 1, quant, "bf16",
                                   cp, 512, 0, "off"))

    # ---- Track B: PD disaggregation ----
    if "B" in job.tracks and job.nodes >= 2:
        for quant, cp, split in itertools.product(
                quants, (4096, 8192, 16384),
                ("1P1D-node", f"{total - gpn // 2}P{gpn // 2}D-gpu")):
            tp = gpn
            ep = min(gpn, facts.n_experts) if facts.is_moe else 1
            consider(Candidate("B", "pd_disagg", tp, ep, 1, 1, quant, "bf16",
                               cp, 512, 0, "off", pd_split=split))

    # ---- Track C: latency / speculative decoding (single-node layouts: fits
    # the v0.2 scheduler's gap-filling; fleet numbers extrapolate by replicas) ----
    if "C" in job.tracks:
        ks = (1, 2, 3, 4) if facts.has_mtp_head else ()
        for quant, k in itertools.product(quants, ks or (0,)):
            if k == 0 and facts.has_mtp_head:
                continue
            consider(Candidate("C", "aggregated", gpn, min(8, max(1, facts.n_experts and 8)),
                               1, 1, quant, "bf16", 4096, 128, k, "off"))
        if not facts.has_mtp_head:
            rejected.append((Candidate("C", "aggregated", gpn, 1, 1, 1,
                                       quants[0], "bf16", 4096, 128, 1, "off"),
                             "no MTP head and no draft model: spec decoding not applicable"))

    # ---- Track D: KV / memory / long-context (single-node layouts) ----
    if "D" in job.tracks:
        for kv_dtype, hic in itertools.product(("bf16", "fp8"), ("off", "l2", "l3")):
            consider(Candidate("D", "aggregated", gpn, min(8, ep_opts[-1]), 1, 1,
                               quants[0], kv_dtype, 8192, 512, 0, hic))

    # ---- Track E: multi-engine bake-off (TRT-LLM mirrors of strong aggregated
    # layouts; no hicache/spec axes in v0.3 — logged as scope, not silently absent) ----
    if "E" in job.tracks:
        for tp, ep, quant in itertools.product((gpn,), (8, 16) if facts.is_moe else (1,), quants):
            for dp in (1, 2):
                for cp in (4096, 8192):
                    consider(Candidate("E", "aggregated", tp, ep, dp, 1, quant,
                                       "bf16", cp, 512, 0, "off", engine="trtllm"))

    # de-dup by cid
    seen, out = set(), []
    for c in feasible:
        if c.cid not in seen:
            seen.add(c.cid)
            out.append(c)
    return out, rejected
