"""--simulate backend: an analytical roofline-style performance model.

Purpose: let the entire agent pipeline (screen -> halve -> refine ->
head-to-head -> report) run end-to-end with zero GPUs, deterministically,
so the workflow, ranking logic, and report are testable and demoable.

The model is deliberately simple and labeled as such in every report it
produces. It captures first-order effects only:
  prefill  ~ compute-bound: active-param FLOPs vs fleet TFLOPs x parallel eff
  decode   ~ memory-bound: active bytes/token vs HBM bandwidth x batch
  quant    -> compute/bandwidth scaling
  EP over EFA, chunk size, spec-decode acceptance, hicache, PD transfer ->
  multiplicative efficiency terms
Noise is seeded by candidate id (reproducible; distinguishes near-ties).
"""
from __future__ import annotations

import hashlib
import math
import random
from .introspect import ModelFacts
from .job import Job, GPU_SPECS, WorkloadProfile
from .search_space import Candidate
from .bench.harness import BenchResult
from .feasibility import BYTES_PER_PARAM, KV_DTYPE_SCALE

QUANT_COMPUTE = {"bf16": 1.0, "fp8": 1.85, "fp4": 3.1}   # effective speedup vs bf16
ACCEPTANCE = {"chat": 0.72, "rag": 0.60, "agent": 0.48}   # per-profile spec-decode accept
MFU = 0.42                                                # achievable prefill MFU
MBU = 0.62                                                # achievable decode bandwidth util


def _rng(c: Candidate, profile: str) -> random.Random:
    seed = int(hashlib.sha256(f"{c.cid}:{profile}".encode()).hexdigest()[:8], 16)
    return random.Random(seed)


ENGINE_EFF = {"sglang": 1.0, "trtllm": 1.04}   # kernel-level edge, no hicache axis


def _parallel_eff(c: Candidate, job: Job, facts: ModelFacts) -> float:
    eff = ENGINE_EFF.get(c.engine, 1.0)
    eff *= 0.97 ** max(0, int(math.log2(c.tp)))          # TP all-reduce cost
    if facts.is_moe and c.ep > 1:
        if c.ep > job.gpus_per_node:                      # all-to-all crosses EFA
            eff *= 0.72
        else:
            eff *= 0.995 ** c.ep
        # wide-EP shrinks per-GPU expert weights -> better decode locality
        eff *= 1.0 + 0.02 * math.log2(c.ep)
    if c.dp > 1:
        eff *= 0.985                                      # DP attention sync
    return eff


def simulate(c: Candidate, job: Job, facts: ModelFacts,
             profile: WorkloadProfile, request_rate: float) -> BenchResult:
    rng = _rng(c, profile.name)
    hbm_gb, tflops_fp8, bw_tbps, _ = GPU_SPECS[job.gpu]
    n = job.total_gpus
    peff = _parallel_eff(c, job, facts)
    qc = QUANT_COMPUTE[c.quant] / QUANT_COMPUTE["fp8"]    # tflops table is fp8-based

    # ---- prefill: compute bound ----
    flops_per_tok = 2 * facts.active_params_b * 1e9
    fleet_flops = n * tflops_fp8 * 1e12 * MFU * peff * qc
    prefill_tps = fleet_flops / flops_per_tok
    chunk_pen = 1.0 - 0.25 * math.exp(-c.chunked_prefill / 4096)  # tiny chunks waste
    prefill_tps *= chunk_pen
    if c.serving_mode == "pd_disagg":
        pfrac = 0.5 if c.pd_split.endswith("node") else (job.total_gpus - job.gpus_per_node // 2) / job.total_gpus
        prefill_tps *= pfrac / 0.5 * 1.18                  # isolation bonus on dedicated prefill
        prefill_tps *= 0.94 if job.inter_node == "efa" else 0.99  # KV transfer tax

    # ---- decode: step-time model (memory- vs compute-bound, MoE-aware) ----
    world = c.tp * c.pp * c.dp
    replicas = max(1, n // world)
    batch = min(c.max_running_reqs, 384)
    group_bw = world * bw_tbps * 1e12 * MBU * peff
    group_flops = world * tflops_fp8 * 1e12 * MFU * peff * qc
    wb = BYTES_PER_PARAM[c.quant]
    dense_bytes = facts.active_params_b * 1e9 * wb * 0.4       # attn + dense + shared
    if facts.is_moe and facts.n_experts:
        frac = 1.0 - (1.0 - facts.experts_per_tok / facts.n_experts) ** batch
        expert_bytes = ((facts.total_params_b - facts.active_params_b) * 1e9
                        * wb * frac * 0.55)                     # scattered-read efficiency
    else:
        expert_bytes = facts.active_params_b * 1e9 * wb * 0.6
    kv_read = batch * 2048 * facts.kv_bytes_per_token_bf16 * KV_DTYPE_SCALE[c.kv_dtype]
    mem_ms = 1000 * (dense_bytes + expert_bytes + kv_read) / group_bw
    comp_ms = 1000 * (2 * facts.active_params_b * 1e9 * batch) / group_flops
    overhead_ms = 3.0 + (0.8 if c.ep > job.gpus_per_node else 0.0)
    step_ms = max(mem_ms, comp_ms) + overhead_ms
    if c.spec_decode:
        acc = ACCEPTANCE.get(profile.name, 0.6) ** (1 + 0.15 * (c.spec_decode - 1))
        step_ms /= max(0.8, (1 + c.spec_decode * acc) / (1 + 0.28 * c.spec_decode))
    decode_tps = 1000.0 / step_ms * batch * replicas
    if c.serving_mode == "pd_disagg":
        dfrac = 0.5 if c.pd_split.endswith("node") else (job.gpus_per_node // 2) / n
        decode_tps *= (dfrac / 0.5) * 1.10                  # no prefill interference
    if c.hicache != "off":
        uplift = 0.06 if c.hicache == "l2" else 0.10
        prefill_tps *= 1 + uplift * (job.prefix_hit_rate / 0.6)
    prefill_tps *= 1 + 0.35 * job.prefix_hit_rate           # prefix cache skips work

    # ---- latency at offered load ----
    offered_in = request_rate * profile.isl
    offered_out = request_rate * profile.osl
    rho_p = min(offered_in / max(prefill_tps, 1), 0.995)
    rho_d = min(offered_out / max(decode_tps, 1), 0.995)
    group_prefill_tps = prefill_tps / max(1, (n * (0.5 if c.serving_mode == "pd_disagg" else 1)) // world)
    ttft = profile.isl / max(group_prefill_tps, 1) + 0.08
    ttft *= 1 / (1 - rho_p)                                 # queueing blow-up
    if c.serving_mode != "pd_disagg":
        ttft *= 1 + 0.6 * rho_d                             # decode interference
    tpot_ms = step_ms * (1 + 0.8 * rho_d / (1 - rho_d) * 0.15)
    if c.serving_mode != "pd_disagg":
        tpot_ms *= 1 + 0.5 * rho_p * (c.chunked_prefill / 16384)

    ttft *= rng.uniform(0.93, 1.07)
    tpot_ms *= rng.uniform(0.95, 1.05)

    # SLO attainment via lognormal-ish spread around p50
    def attain(p95_est, slo):
        if p95_est <= slo:
            return min(1.0, 0.97 + 0.03 * (slo / p95_est - 1))
        return max(0.0, 1.0 - min(1.0, (p95_est / slo - 1) * 1.8))

    a = attain(ttft * 1.6, job.slo_ttft_p95_s) * attain(tpot_ms * 1.35, job.slo_tpot_p95_ms)
    served_in = min(offered_in, prefill_tps)
    served_out = min(offered_out, decode_tps)
    return BenchResult(
        profile=profile.name, request_rate=request_rate,
        input_tps=served_in, output_tps=served_out,
        ttft_p50_s=round(ttft, 3), ttft_p95_s=round(ttft * 1.6, 3),
        tpot_p95_ms=round(tpot_ms * 1.35, 2),
        goodput_rps=round(request_rate * a, 3),
        goodput_output_tps=round(served_out * a, 1),
        slo_attainment=round(a, 4),
    )


def crash_probability(c: Candidate) -> float:
    """Simulated launch-failure modes for screening realism."""
    p = 0.0
    if c.spec_decode >= 4:
        p += 0.35          # draft-length instability
    if c.kv_dtype == "fp8" and c.hicache == "l3":
        p += 0.25          # kernel/storage interaction, engine-version dependent
    if c.chunked_prefill <= 2048 and c.max_running_reqs >= 512:
        p += 0.15
    if c.engine == "trtllm" and c.ep > 8:
        p += 0.20          # wide-EP path less mature on second engine (sim)
    return min(p, 0.9)
