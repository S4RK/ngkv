"""Stage 0 — model introspection.

Reads config.json (HF hub or local path) and derives the facts the search
needs: parameter/expert structure, attention type (and hence KV bytes/token),
available quantizations, and speculative-decoding applicability.
No weight download is required for this stage.
"""
from __future__ import annotations

import json
import os
import urllib.request
from dataclasses import dataclass, asdict
from pathlib import Path


@dataclass
class ModelFacts:
    model_id: str
    architecture: str
    n_layers: int
    hidden_size: int
    n_heads: int
    n_kv_heads: int
    attention_type: str          # mha | gqa | mla
    is_moe: bool
    n_experts: int
    experts_per_tok: int
    n_shared_experts: int
    total_params_b: float        # estimate, billions
    active_params_b: float       # per-token active, billions
    max_position: int
    native_dtype: str            # bf16 | fp8 | fp4
    kv_bytes_per_token_bf16: int # per layer summed, at bf16 KV
    has_mtp_head: bool           # multi-token-prediction head -> spec decode w/o draft
    notes: list[str]

    def to_dict(self):
        return asdict(self)


def _fetch_config(model_id: str, revision: str) -> dict:
    p = Path(model_id)
    if p.exists():
        return json.loads((p / "config.json").read_text())
    url = f"https://huggingface.co/{model_id}/resolve/{revision}/config.json"
    req = urllib.request.Request(url)  # noqa: S310
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    with urllib.request.urlopen(req, timeout=30) as r:  # noqa: S310
        return json.loads(r.read().decode())


def _unwrap(cfg: dict) -> dict:
    """Multimodal checkpoints (Gemma 3/4 style) nest the LLM under text_config;
    day0 serves the language model, so flatten it over the top level."""
    inner = cfg.get("text_config")
    if isinstance(inner, dict) and "num_hidden_layers" in inner:
        return {**cfg, **inner}
    return cfg


def introspect(model_id: str, revision: str = "main",
               config_override: dict | None = None) -> ModelFacts:
    cfg = config_override if config_override is not None else _fetch_config(model_id, revision)
    cfg = _unwrap(cfg)
    notes: list[str] = []
    if "text_config" in (config_override or {}) or "text_config" in cfg:
        notes.append("multimodal checkpoint: introspected the nested text_config "
                     "(day0 optimizes text serving; vision/audio towers excluded "
                     "from parameter estimates)")

    arch = (cfg.get("architectures") or ["unknown"])[0]
    n_layers = int(cfg.get("num_hidden_layers", 0))
    hidden = int(cfg.get("hidden_size", 0))
    n_heads = int(cfg.get("num_attention_heads", 1))
    n_kv = int(cfg.get("num_key_value_heads", n_heads))
    head_dim = int(cfg.get("head_dim") or (hidden // max(n_heads, 1)))

    # Attention type: MLA is detected via latent-KV fields (DeepSeek-style).
    kv_lora_rank = cfg.get("kv_lora_rank")
    qk_rope_dim = int(cfg.get("qk_rope_head_dim", 0) or 0)
    if kv_lora_rank:
        attn = "mla"
        kv_per_tok_layer = (int(kv_lora_rank) + qk_rope_dim) * 2  # bf16 bytes
        notes.append(f"MLA latent KV: rank={kv_lora_rank}, rope_dim={qk_rope_dim} "
                     f"-> {kv_per_tok_layer} B/token/layer (bf16) vs "
                     f"{2 * 2 * n_kv * head_dim} for GQA equivalent")
    elif n_kv < n_heads:
        attn = "gqa"
        kv_per_tok_layer = 2 * 2 * n_kv * head_dim
    else:
        attn = "mha"
        kv_per_tok_layer = 2 * 2 * n_heads * head_dim

    # MoE structure
    n_experts = int(cfg.get("n_routed_experts") or cfg.get("num_experts")
                    or cfg.get("num_local_experts") or 0)
    is_moe = n_experts > 0
    topk = int(cfg.get("num_experts_per_tok") or cfg.get("top_k_experts")
               or cfg.get("num_experts_per_token") or cfg.get("moe_top_k") or 0)
    n_shared = int(cfg.get("n_shared_experts", 0) or 0)
    moe_inter = int(cfg.get("moe_intermediate_size", 0) or 0)
    dense_inter = int(cfg.get("intermediate_size", 0) or 0)
    vocab = int(cfg.get("vocab_size", 0))

    # Parameter estimates (order-of-magnitude honest; exact count comes from the
    # weight index in a later refinement — good enough for memory pruning).
    attn_params = n_layers * 4 * hidden * hidden * (0.35 if attn == "mla" else 1.0)
    if is_moe:
        first_dense = int(cfg.get("first_k_dense_replace", 0) or 0)
        moe_layers = n_layers - first_dense
        expert_p = 3 * hidden * moe_inter
        ffn_total = (moe_layers * (n_experts + n_shared) * expert_p
                     + first_dense * 3 * hidden * dense_inter)
        ffn_active = (moe_layers * (topk + n_shared) * expert_p
                      + first_dense * 3 * hidden * dense_inter)
    else:
        ffn_total = ffn_active = n_layers * 3 * hidden * dense_inter
    emb = 2 * vocab * hidden
    total_b = (attn_params + ffn_total + emb) / 1e9
    active_b = (attn_params + ffn_active + emb) / 1e9

    qcfg = cfg.get("quantization_config") or {}
    native = "bf16"
    fmt = str(qcfg.get("quant_method", "") or qcfg.get("fmt", "")).lower()
    if "fp8" in fmt or "fp8" in str(qcfg.get("weight_block_size", "")):
        native = "fp8"
    if "fp4" in fmt or "nvfp4" in fmt:
        native = "fp4"
    if native == "bf16" and not qcfg:
        notes.append("no quantization_config in checkpoint; FP8 variant availability "
                     "should be probed on the hub (potential 1.5-2x if absent)")

    lt = cfg.get("layer_types") or []
    n_sliding = sum(1 for t in lt if "sliding" in str(t))
    if n_sliding:
        notes.append(f"hybrid attention: {n_sliding}/{len(lt)} layers sliding-window "
                     f"(window={cfg.get('sliding_window')}); KV-per-token estimate "
                     "assumes all-global and is therefore conservative for capacity")

    has_mtp = bool(cfg.get("num_nextn_predict_layers", 0)) or "mtp" in json.dumps(cfg).lower()
    if has_mtp:
        notes.append("MTP head present -> speculative decoding without external draft (Track C)")

    return ModelFacts(
        model_id=model_id, architecture=arch, n_layers=n_layers, hidden_size=hidden,
        n_heads=n_heads, n_kv_heads=n_kv, attention_type=attn, is_moe=is_moe,
        n_experts=n_experts, experts_per_tok=topk, n_shared_experts=n_shared,
        total_params_b=round(total_b, 1), active_params_b=round(active_b, 1),
        max_position=int(cfg.get("max_position_embeddings", 0)),
        native_dtype=native, kv_bytes_per_token_bf16=kv_per_tok_layer * n_layers,
        has_mtp_head=has_mtp, notes=notes,
    )
