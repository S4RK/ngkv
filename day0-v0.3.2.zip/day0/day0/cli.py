"""day0 CLI.

  day0 run job.yaml [--simulate] [--out DIR]
  day0 introspect <hf_id>
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from .job import load_job
from .introspect import introspect
from . import search_space
from .runner import head_to_head
from .gate import run_gate
from .report import write_report
from .store import Store

# Cached config for offline/simulate runs (DeepSeek-V4-class MoE shape).
_CACHED = Path(__file__).parent.parent / "configs" / "cached_model_configs"


def _facts(model_id: str, revision: str, offline: bool):
    if offline:
        cache = _CACHED / (model_id.replace("/", "__") + ".json")
        if cache.exists():
            return introspect(model_id, revision,
                              config_override=json.loads(cache.read_text()))
        print(f"[day0] no cached config for {model_id}; fetching from hub...")
    return introspect(model_id, revision)


def cmd_run(args):
    t0 = time.time()
    job = load_job(args.job)
    out = Path(args.out or f"day0-{job.digest()}")
    out.mkdir(parents=True, exist_ok=True)
    store = Store(out / "runs.sqlite")
    store.meta("job", job.raw)
    store.meta("mode", "simulate" if args.simulate else "cluster")

    print(f"[day0] Stage 0: introspecting {job.model_id}")
    facts = _facts(job.model_id, job.model_revision, offline=args.simulate)
    store.meta("model_facts", facts.to_dict())
    print(f"       {facts.architecture}: ~{facts.total_params_b}B total / "
          f"~{facts.active_params_b}B active, attn={facts.attention_type}, "
          f"MoE={facts.n_experts}xtop{facts.experts_per_tok}, "
          f"native={facts.native_dtype}, MTP={facts.has_mtp_head}")
    for n in facts.notes:
        print(f"       note: {n}")

    print("[day0] Stage 1+2: search space")
    cands, rejected = search_space.generate(facts, job)
    for c, reason in rejected:
        store.trial(cid=c.cid, track=c.track, rung="feasibility", stage="stage1",
                    label=c.label(), config=c.__dict__ | {"cid": c.cid},
                    status="pruned", reason=reason)
    by_track: dict[str, list] = {}
    for c in cands:
        by_track.setdefault(c.track, []).append(c)
    print(f"       {len(cands)} feasible candidates "
          f"({', '.join(f'{t}:{len(v)}' for t, v in sorted(by_track.items()))}); "
          f"{len(rejected)} pruned by arithmetic")

    # v0.3: cross-model warm-starts from the registry
    from . import priors
    if not args.no_priors:
        for t in by_track:
            ordered, promoted, why = priors.warm_start(facts, by_track[t])
            by_track[t] = ordered
            for r in why:
                store.decide("priors", t, r)
                print(f"       warm-start [{t}]: {r}")

    # v0.2: concurrent tracks under the node pool + wall-clock budget
    from . import scheduler
    from .runner import successive_halving
    print(f"[day0] Tracks {'+'.join(sorted(by_track))}: scheduled over "
          f"{job.nodes} nodes, budget {job.wall_clock_h}h")
    champions = scheduler.run_tracks(by_track, job, facts, store,
                                     simulate=args.simulate,
                                     halving_fn=successive_halving)
    for t in sorted(champions):
        champ = champions[t]
        print(f"       Track {t} champion: {champ.candidate.label()} "
              f"-> {champ.score:,.0f} out tok/s goodput")
    for t in sorted(set(by_track) - set(champions)):
        print(f"       Track {t} produced no viable config (see runs.sqlite)")

    if not champions:
        print("[day0] no track produced a viable config; aborting with report of failures")
        sys.exit(2)

    print("[day0] Stage 3: head-to-head (interleaved x2, full mix)")
    ranked = head_to_head(champions, job, facts, store, simulate=args.simulate)

    print("[day0] Stage 4: accuracy gate")
    gate = run_gate(job.model_id, ranked[0][1].candidate.label(),
                    simulate=args.simulate)
    print(f"       gate: {gate.status}")

    print("[day0] Stage 5: report")
    rpt = write_report(out, job, facts, ranked, gate, store, simulate=args.simulate)
    if not args.no_priors:
        wt, wo = ranked[0]
        rec = priors.record_run(facts, wo.candidate.__dict__ | {"cid": wo.candidate.cid},
                                wo.score, job.digest(),
                                "simulate" if args.simulate else "cluster")
        print(f"       registered in warm-start registry: {rec.name}")
    store.meta("wall_clock_s", round(time.time() - t0, 1))
    store.close()
    print(f"[day0] done in {time.time() - t0:.1f}s -> {rpt}")
    return rpt


def cmd_preflight(args):
    from .preflight import run_preflight, verdict
    job = load_job(args.job)
    checks = run_preflight(job)
    width = max(len(c.name) for c in checks)
    for c in checks:
        print(f"  [{c.status:^4}] {c.name:<{width}}  {c.detail}")
    ok = verdict(checks)
    print(f"[day0] preflight: {'GO' if ok else 'NO-GO (fix FAILs above)'}")
    sys.exit(0 if ok else 1)


def cmd_introspect(args):
    facts = _facts(args.model, "main", offline=args.offline)
    print(json.dumps(facts.to_dict(), indent=2))


def main(argv=None):
    ap = argparse.ArgumentParser(prog="day0")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="run the full day-0 search")
    r.add_argument("job")
    r.add_argument("--simulate", action="store_true",
                   help="use the analytical model instead of GPUs (demo/CI)")
    r.add_argument("--out", default=None)
    r.add_argument("--no-priors", action="store_true",
                   help="disable cross-model warm-starts and registry recording")
    r.set_defaults(fn=cmd_run)
    p = sub.add_parser("preflight", help="verify cluster prerequisites before a live run")
    p.add_argument("job")
    p.set_defaults(fn=cmd_preflight)
    i = sub.add_parser("introspect", help="Stage 0 only")
    i.add_argument("model")
    i.add_argument("--offline", action="store_true")
    i.set_defaults(fn=cmd_introspect)
    args = ap.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    main()
