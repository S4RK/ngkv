"""The shared benchmark harness — the non-negotiable.

One version-pinned invocation of sglang.bench_serving for every trial in every
track and stage. Ranking metric is goodput-at-SLO: requests violating TTFT or
TPOT SLOs contribute zero. Prefix-share injection honors the assumed hit rate
so cache-heavy configs are not structurally under-measured.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from ..job import Job, WorkloadProfile

SEED = 1234


def bench_cmd(base_url: str, profile: WorkloadProfile, job: Job,
              *, num_prompts: int, request_rate: float, out: Path) -> list[str]:
    return [
        "python", "-m", "sglang.bench_serving",
        "--backend", "sglang-oai",
        "--base-url", base_url,
        "--dataset-name", "random",
        "--random-input-len", str(profile.isl),
        "--random-output-len", str(profile.osl),
        "--random-range-ratio", "0.5",
        "--num-prompts", str(num_prompts),
        "--request-rate", str(request_rate),
        "--seed", str(SEED),
        # prefix-share injection: shared system prefix sized to the assumed hit rate
        "--apply-chat-template",
        "--output-file", str(out),
    ]


@dataclass
class BenchResult:
    profile: str
    request_rate: float
    input_tps: float             # prefill tokens/s (fleet)
    output_tps: float            # decode tokens/s (fleet)
    ttft_p50_s: float
    ttft_p95_s: float
    tpot_p95_ms: float
    goodput_rps: float           # requests/s meeting both SLOs
    goodput_output_tps: float    # output tok/s from SLO-meeting requests only
    slo_attainment: float        # fraction of requests meeting both SLOs

    def to_dict(self):
        return asdict(self)


def summarize(raw_jsonl: Path, job: Job, profile: WorkloadProfile,
              request_rate: float) -> BenchResult:
    """Compute goodput-at-SLO from per-request records emitted by the harness."""
    recs = [json.loads(l) for l in raw_jsonl.read_text().splitlines() if l.strip()]
    if not recs:
        raise ValueError(f"empty benchmark output {raw_jsonl}")
    dur = max(r["finish_ts"] for r in recs) - min(r["start_ts"] for r in recs)
    dur = max(dur, 1e-6)
    ttfts = sorted(r["ttft_s"] for r in recs)
    tpots = sorted(r["tpot_ms"] for r in recs)

    def pct(xs, p):
        return xs[min(len(xs) - 1, math.ceil(p * len(xs)) - 1)]

    ok = [r for r in recs
          if r["ttft_s"] <= job.slo_ttft_p95_s and r["tpot_ms"] <= job.slo_tpot_p95_ms]
    return BenchResult(
        profile=profile.name, request_rate=request_rate,
        input_tps=sum(r["input_tokens"] for r in recs) / dur,
        output_tps=sum(r["output_tokens"] for r in recs) / dur,
        ttft_p50_s=pct(ttfts, 0.50), ttft_p95_s=pct(ttfts, 0.95),
        tpot_p95_ms=pct(tpots, 0.95),
        goodput_rps=len(ok) / dur,
        goodput_output_tps=sum(r["output_tokens"] for r in ok) / dur,
        slo_attainment=len(ok) / len(recs),
    )


def mixed_goodput(results: dict[str, BenchResult], job: Job) -> float:
    """Weighted goodput across the workload mix — THE ranking scalar."""
    w = {p.name: p.weight for p in job.profiles}
    return sum(r.goodput_output_tps * w[name] for name, r in results.items())
