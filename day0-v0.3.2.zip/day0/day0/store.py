"""runs.sqlite — every trial, every failure, every rationale. WAL mode."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS trials (
  cid TEXT, track TEXT, rung TEXT, stage TEXT,
  label TEXT, config_json TEXT,
  status TEXT,            -- ok | crash | oom | slo_infeasible | pruned
  reason TEXT,
  score REAL,             -- mixed goodput (output tok/s at SLO), NULL if failed
  results_json TEXT,
  ts REAL
);
CREATE TABLE IF NOT EXISTS decisions (
  ts REAL, stage TEXT, action TEXT, rationale TEXT
);
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
"""


class Store:
    def __init__(self, path: Path):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self._lock = threading.Lock()
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript(SCHEMA)

    def meta(self, k: str, v):
      with self._lock:
        self.db.execute("INSERT OR REPLACE INTO meta VALUES (?,?)", (k, json.dumps(v)))
        self.db.commit()

    def trial(self, *, cid, track, rung, stage, label, config, status,
              reason="", score=None, results=None):
      with self._lock:
        self.db.execute(
            "INSERT INTO trials VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (cid, track, rung, stage, label, json.dumps(config), status, reason,
             score, json.dumps(results) if results else None, time.time()))
        self.db.commit()

    def decide(self, stage: str, action: str, rationale: str):
      with self._lock:
        self.db.execute("INSERT INTO decisions VALUES (?,?,?,?)",
                        (time.time(), stage, action, rationale))
        self.db.commit()

    def failures(self):
        return self.db.execute(
            "SELECT track, label, status, reason FROM trials "
            "WHERE status != 'ok' ORDER BY track, status").fetchall()

    def close(self):
        self.db.close()
