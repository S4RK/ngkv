"""Stage 4 — accuracy gate via agate.

If the agate CLI is on PATH, the winner (and runner-up) are gated against the
reference config with paired McNemar + bootstrap CI, digest-keyed baseline.
A config that wins throughput but fails the gate is DEMOTED, not shipped;
its numbers appear struck-through in the report.

If agate is absent (e.g. simulate mode on a laptop), the gate is recorded as
SKIPPED — never silently passed.
"""
from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass


@dataclass
class GateResult:
    status: str      # pass | fail | skipped
    detail: str


def run_gate(model_id: str, candidate_label: str, *, simulate: bool) -> GateResult:
    if simulate:
        return GateResult("skipped",
                          "simulate mode: no model outputs to compare; "
                          "gate MUST run before production promotion")
    if shutil.which("agate") is None:
        return GateResult("skipped",
                          "agate not found on PATH; gate MUST run before production promotion")
    proc = subprocess.run(  # noqa: S603
        ["agate", "run", "--model", model_id, "--suite", "agate-default",
         "--candidate-label", candidate_label],
        capture_output=True, text=True)
    if proc.returncode == 0:
        return GateResult("pass", proc.stdout.strip()[-2000:])
    return GateResult("fail", (proc.stdout + proc.stderr).strip()[-2000:])
