"""Stage 5 — the deployment record.

Mandatory sections: winner + launch command + envelope; Pareto table across
finalists; WHAT DIDN'T WORK (every failure with its class and cause);
reproduction block.
"""
from __future__ import annotations

import json
import shlex
import time
from pathlib import Path

from .job import Job
from .introspect import ModelFacts
from .runner import TrialOutcome
from .gate import GateResult
from .engines.sglang import launch_cmd
from .store import Store

TRACK_NAMES = {
    "A": "Aggregated max-throughput",
    "B": "PD disaggregation",
    "C": "Latency / speculative decoding",
    "D": "KV / memory / long-context",
    "E": "Multi-engine bake-off (TRT-LLM)",
}


def write_report(out_dir: Path, job: Job, facts: ModelFacts,
                 ranked: list[tuple[str, TrialOutcome]],
                 gate: GateResult, store: Store, *, simulate: bool) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    winner_track, winner = ranked[0]
    wc = winner.candidate

    # winner/serve.yaml + launch command
    wdir = out_dir / "winner"
    wdir.mkdir(exist_ok=True)
    cmd = launch_cmd(wc, job)
    (wdir / "serve.yaml").write_text(json.dumps(
        {"candidate": wc.__dict__ | {"cid": wc.cid}, "launch_cmd": cmd}, indent=2))
    (wdir / "launch.sh").write_text("#!/usr/bin/env bash\nset -euo pipefail\n"
                                    + shlex.join(cmd) + "\n")

    # envelope.json — CN-01 topology-catalog format
    env = {
        "state_name": f"day0-{facts.model_id.split('/')[-1]}-{wc.cid}",
        "certified_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "measurement_source": "SIMULATED-ANALYTICAL-MODEL" if simulate else "cluster-benchmark",
        "config": wc.__dict__ | {"cid": wc.cid},
        "envelope": {p: r.to_dict() for p, r in winner.per_profile.items()},
        "mixed_goodput_output_tps": winner.score,
        "slo": {"ttft_p95_s": job.slo_ttft_p95_s, "tpot_p95_ms": job.slo_tpot_p95_ms},
        "accuracy_gate": gate.__dict__,
    }
    (out_dir / "envelope.json").write_text(json.dumps(env, indent=2))

    # ---- report.md ----
    L: list[str] = []
    A = L.append
    A(f"# day0 deployment record — {facts.model_id}")
    A("")
    if simulate:
        A("> **SIMULATED RUN.** All performance numbers below come from day0's "
          "analytical model (roofline-style, first-order effects only), not from "
          "hardware. This run demonstrates the pipeline and report format. "
          "Re-run without `--simulate` on the cluster for real numbers.")
        A("")
    A(f"- Hardware: {job.nodes}x{job.gpus_per_node} {job.gpu} ({job.total_gpus} GPUs), "
      f"inter-node {job.inter_node}")
    A(f"- Model: {facts.architecture}, ~{facts.total_params_b}B total / "
      f"~{facts.active_params_b}B active, attention={facts.attention_type}, "
      f"MoE={facts.n_experts}x top-{facts.experts_per_tok}"
      f"+{facts.n_shared_experts} shared, native dtype={facts.native_dtype}")
    A(f"- SLO: TTFT p95 <= {job.slo_ttft_p95_s}s, TPOT p95 <= {job.slo_tpot_p95_ms}ms; "
      f"ranking metric: **goodput at SLO** (weighted across the workload mix)")
    A("")

    A("## Winner")
    A("")
    gate_note = {"pass": "accuracy gate: PASS",
                 "fail": "accuracy gate: **FAIL — DEMOTED, do not ship**",
                 "skipped": f"accuracy gate: SKIPPED ({gate.detail.split(';')[0]})"}[gate.status]
    A(f"**Track {winner_track} — {TRACK_NAMES[winner_track]}**  |  {gate_note}")
    A("")
    A(f"`{wc.label()}`")
    A("")
    A(f"Mixed goodput: **{winner.score:,.0f} output tok/s at SLO** (fleet). "
      f"Launch: `winner/launch.sh`; envelope for the CN-01 topology catalog: `envelope.json`.")
    if job.reference_goal_input_tps_per_node:
        best_in = max((r.input_tps for r in winner.per_profile.values()), default=0)
        per_node = best_in / job.nodes
        goal = job.reference_goal_input_tps_per_node
        A(f"\nReference goal: {goal:,} input tok/s/node. Achieved (best profile): "
          f"{per_node:,.0f}/node = {per_node / goal:.0%} of goal.")
    A("")

    A("## Head-to-head (Stage 3 — the only cross-track table)")
    A("")
    A("| Rank | Track | Champion | Mixed goodput (out tok/s @ SLO) | TTFT p95 (chat) | TPOT p95 (chat) |")
    A("|---|---|---|---|---|---|")
    for i, (t, o) in enumerate(ranked, 1):
        chat = o.per_profile.get("chat") or next(iter(o.per_profile.values()))
        strike = "~~" if (i == 1 and gate.status == "fail") else ""
        A(f"| {i} | {t}: {TRACK_NAMES[t]} | `{o.candidate.label()}` | "
          f"{strike}{o.score:,.0f}{strike} | {chat.ttft_p95_s:.2f}s | {chat.tpot_p95_ms:.1f}ms |")
    A("")

    A("## Per-profile detail (winner)")
    A("")
    A("| Profile | Input tok/s | Output tok/s | TTFT p95 | TPOT p95 | SLO attainment | Goodput out tok/s |")
    A("|---|---|---|---|---|---|---|")
    for p, r in winner.per_profile.items():
        A(f"| {p} | {r.input_tps:,.0f} | {r.output_tps:,.0f} | {r.ttft_p95_s:.2f}s | "
          f"{r.tpot_p95_ms:.1f}ms | {r.slo_attainment:.1%} | {r.goodput_output_tps:,.0f} |")
    A("")

    A("## What didn't work")
    A("")
    fails = store.failures()
    if not fails:
        A("(no failures recorded — suspicious; check screening thresholds)")
    by_class: dict[str, list] = {}
    for track, label, status, reason in fails:
        by_class.setdefault(status, []).append((track, label, reason))
    for status, rows in sorted(by_class.items()):
        A(f"**{status}** ({len(rows)}):")
        A("")
        seen = set()
        for track, label, reason in rows:
            key = (track, reason)
            if key in seen:
                continue
            seen.add(key)
            A(f"- [{track}] `{label}` — {reason}")
        A("")

    A("## Reproduction")
    A("")
    A(f"- Job digest: `{job.digest()}`  |  seed: 1234  |  harness: sglang.bench_serving (pinned)")
    A(f"- Full trial log: `runs.sqlite` (WAL; tables `trials`, `decisions`)")
    A(f"- Mode: {'simulate (analytical model)' if simulate else 'cluster'}")
    A("")
    p = out_dir / "report.md"
    p.write_text("\n".join(L))
    return p
