import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from day0.job import load_job                      # noqa: E402
from day0.introspect import introspect             # noqa: E402
from day0 import feasibility, search_space         # noqa: E402

JOB = ROOT / "configs" / "example-job.yaml"
CFG = json.loads((ROOT / "configs" / "cached_model_configs" /
                  "deepseek-ai__DeepSeek-V4-Flash-0731.json").read_text())


def facts():
    return introspect("deepseek-ai/DeepSeek-V4-Flash-0731", config_override=CFG)


def test_introspect_detects_mla_moe_mtp():
    f = facts()
    assert f.attention_type == "mla"
    assert f.is_moe and f.n_experts == 256 and f.experts_per_tok == 8
    assert f.has_mtp_head
    assert f.native_dtype == "fp8"
    assert 400 < f.total_params_b < 900          # order-of-magnitude sanity
    assert f.active_params_b < f.total_params_b / 5


def test_feasibility_prunes_cross_node_tp_and_oom():
    f, j = facts(), load_job(JOB)
    v = feasibility.check(f, j, tp=16, ep=1, pp=1, dp=1, quant="fp8", kv_dtype="bf16")
    assert not v.ok and "crosses node" in v.reason
    v = feasibility.check(f, j, tp=1, ep=1, pp=1, dp=1, quant="bf16", kv_dtype="bf16")
    assert not v.ok                               # ~700B bf16 on one GPU: OOM
    v = feasibility.check(f, j, tp=8, ep=8, pp=1, dp=2, quant="fp8", kv_dtype="bf16")
    assert v.ok, v.reason
    assert v.weight_gb_per_gpu < 180 * 0.92


def test_search_space_partitions_tracks_and_records_rejections():
    f, j = facts(), load_job(JOB)
    cands, rejected = search_space.generate(f, j)
    tracks = {c.track for c in cands}
    assert tracks == {"A", "B", "C", "D", "E"}
    assert len(cands) >= 20
    assert len(rejected) >= 5
    assert all(r for _, r in rejected)            # every rejection has a reason


def test_end_to_end_simulate(tmp_path):
    out = tmp_path / "run"
    r = subprocess.run(
        [sys.executable, "-m", "day0.cli", "run", str(JOB),
         "--simulate", "--no-priors", "--out", str(out)],
        cwd=ROOT, capture_output=True, text=True, timeout=300)
    assert r.returncode == 0, r.stderr
    assert (out / "report.md").exists()
    assert (out / "envelope.json").exists()
    assert (out / "winner" / "launch.sh").exists()
    assert (out / "runs.sqlite").exists()
    rpt = (out / "report.md").read_text()
    assert "SIMULATED RUN" in rpt
    assert "What didn't work" in rpt
    env = json.loads((out / "envelope.json").read_text())
    assert env["measurement_source"] == "SIMULATED-ANALYTICAL-MODEL"
    assert env["accuracy_gate"]["status"] == "skipped"


def test_simulate_is_deterministic(tmp_path):
    outs = []
    for i in range(2):
        out = tmp_path / f"run{i}"
        subprocess.run([sys.executable, "-m", "day0.cli", "run", str(JOB),
                        "--simulate", "--no-priors", "--out", str(out)],
                       cwd=ROOT, capture_output=True, text=True, check=True, timeout=300)
        env = json.loads((out / "envelope.json").read_text())
        outs.append((env["config"]["cid"], env["mixed_goodput_output_tps"]))
    assert outs[0] == outs[1]
