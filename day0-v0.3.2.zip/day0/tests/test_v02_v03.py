import json
import random
import subprocess
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from day0.job import load_job                          # noqa: E402
from day0.introspect import introspect                 # noqa: E402
from day0 import bayes, priors, scheduler, search_space  # noqa: E402
from day0.engines import trtllm                        # noqa: E402
from day0.search_space import Candidate                # noqa: E402

JOB = ROOT / "configs" / "example-job.yaml"
CFG = json.loads((ROOT / "configs" / "cached_model_configs" /
                  "deepseek-ai__DeepSeek-V4-Flash-0731.json").read_text())


def facts():
    return introspect("deepseek-ai/DeepSeek-V4-Flash-0731", config_override=CFG)


# ---------------- v0.2: scheduler ----------------

def test_node_pool_never_oversubscribes():
    pool = scheduler.NodePool(2)
    in_use, max_seen, lock = [0], [0], threading.Lock()

    def worker(n):
        with pool.acquire(n) as nodes:
            with lock:
                in_use[0] += len(nodes)
                max_seen[0] = max(max_seen[0], in_use[0])
            time.sleep(0.01)
            with lock:
                in_use[0] -= len(nodes)

    threads = [threading.Thread(target=worker, args=(n,))
               for n in (2, 1, 1, 2, 1, 1, 2)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=10)
    assert max_seen[0] <= 2


def test_nodes_needed_pd_and_single_node():
    j = load_job(JOB)
    pd = Candidate("B", "pd_disagg", 8, 8, 1, 1, "fp8", "bf16", 4096, 512, 0,
                   "off", pd_split="1P1D-node")
    assert scheduler.nodes_needed(pd, j) == 2
    single = Candidate("D", "aggregated", 8, 8, 1, 1, "fp8", "bf16", 8192, 512, 0, "off")
    assert scheduler.nodes_needed(single, j) == 1
    full = Candidate("A", "aggregated", 8, 8, 2, 1, "fp8", "bf16", 8192, 512, 0, "off")
    assert scheduler.nodes_needed(full, j) == 2


def test_budget_shortens_ladder_when_over():
    j = load_job(JOB)
    b = scheduler.Budget.from_job(j)
    cap = b.phase_cap("refine")
    b.charge("refine", cap * 0.95)
    assert b.ladder_factor("refine", cap * 0.2) < 1.0
    assert b.ladder_factor("search", 10.0) == 1.0


# ---------------- v0.3: TPE ----------------

def test_tpe_beats_random_on_synthetic():
    space = bayes.REFINE_AXES
    optimum = {"chunked_prefill": 8192, "max_running_reqs": 384,
               "kv_dtype": "fp8", "spec_decode": 2, "hicache": "l2"}

    def f(x):
        return sum(3.0 if x[a] == optimum[a] else 0.0 for a in space) \
            - 0.001 * abs(hash(tuple(sorted(x.items())))) % 1

    def run(strategy_rng, use_tpe):
        hist = []
        for _ in range(30):
            if use_tpe:
                x = bayes.tpe_suggest(hist, space, strategy_rng)
            else:
                x = {a: strategy_rng.choice(vs) for a, vs in space.items()}
            hist.append((x, f(x)))
        return max(h[1] for h in hist)

    tpe_wins = sum(run(random.Random(1000 + s), True)
                   >= run(random.Random(2000 + s), False) for s in range(5))
    assert tpe_wins >= 3          # TPE at least matches random most seeds


def test_refine_space_respects_engine_and_mtp():
    c_sgl = Candidate("A", "aggregated", 8, 8, 2, 1, "fp8", "bf16", 8192, 512, 0, "off")
    s = bayes.refine_space(c_sgl, mtp=False)
    assert s["spec_decode"] == [0]
    c_trt = Candidate("E", "aggregated", 8, 8, 1, 1, "fp8", "bf16", 8192, 512, 0,
                      "off", engine="trtllm")
    s = bayes.refine_space(c_trt, mtp=True)
    assert s["hicache"] == ["off"] and s["spec_decode"] == [0]


# ---------------- v0.3: priors ----------------

def test_warm_start_promotes_matching_config(tmp_path, monkeypatch):
    monkeypatch.setenv("DAY0_REGISTRY", str(tmp_path))
    f, j = facts(), load_job(JOB)
    cands, _ = search_space.generate(f, j)
    a_cands = [c for c in cands if c.track == "A"]
    target = a_cands[len(a_cands) // 2]
    priors.record_run(f, target.__dict__ | {"cid": target.cid}, 40000.0,
                      "testjob", "simulate")
    ordered, promoted, why = priors.warm_start(f, a_cands)
    assert promoted, "expected at least one promotion"
    assert ordered[0].cid in promoted
    assert "similarity" in why[0]


def test_warm_start_ignores_dissimilar_models(tmp_path, monkeypatch):
    monkeypatch.setenv("DAY0_REGISTRY", str(tmp_path))
    f, j = facts(), load_job(JOB)
    cands, _ = search_space.generate(f, j)
    dense_facts = {"attention_type": "gqa", "is_moe": False,
                   "total_params_b": 8.0, "has_mtp_head": False}
    rec = {"ts": 0, "job_digest": "x", "mode": "simulate",
           "model_facts": dense_facts,
           "winner": cands[0].__dict__ | {"cid": cands[0].cid}, "score": 1.0}
    (tmp_path / "x-0.json").write_text(json.dumps(rec))
    _, promoted, _ = priors.warm_start(f, cands)
    assert not promoted


# ---------------- v0.3: trtllm ----------------

def test_trtllm_cmd_builder():
    j = load_job(JOB)
    c = Candidate("E", "aggregated", 8, 8, 1, 1, "fp8", "fp8", 8192, 512, 0,
                  "off", engine="trtllm")
    cmd = trtllm.launch_cmd(c, j)
    assert cmd[0] == "trtllm-serve"
    assert "--tp_size" in cmd and cmd[cmd.index("--tp_size") + 1] == "8"
    assert "--kv_cache_dtype" in cmd
    pd = Candidate("E", "pd_disagg", 8, 8, 1, 1, "fp8", "bf16", 8192, 512, 0,
                   "off", engine="trtllm", pd_split="1P1D-node")
    try:
        trtllm.launch_cmd(pd, j)
        raise AssertionError("expected ValueError for pd_disagg on trtllm v0.3")
    except ValueError:
        pass


# ---------------- v0.2+v0.3: e2e with all five tracks ----------------

def test_e2e_five_tracks_with_registry(tmp_path):
    reg = tmp_path / "reg"
    env = {"DAY0_REGISTRY": str(reg), "PATH": "/usr/bin:/bin"}
    out1 = tmp_path / "r1"
    r = subprocess.run([sys.executable, "-m", "day0.cli", "run", str(JOB),
                        "--simulate", "--out", str(out1)],
                       cwd=ROOT, capture_output=True, text=True, timeout=600, env=env)
    assert r.returncode == 0, r.stderr
    rpt = (out1 / "report.md").read_text()
    assert "Multi-engine bake-off (TRT-LLM)" in rpt
    assert len(list(reg.glob("*.json"))) == 1
    # second run warm-starts from the first
    out2 = tmp_path / "r2"
    r2 = subprocess.run([sys.executable, "-m", "day0.cli", "run", str(JOB),
                         "--simulate", "--out", str(out2)],
                        cwd=ROOT, capture_output=True, text=True, timeout=600, env=env)
    assert r2.returncode == 0, r2.stderr
    assert "warm-start" in r2.stdout


# ---------------- v0.3.1: multimodal nested config ----------------

def test_introspect_unwraps_text_config():
    # synthetic fixture exercising the Gemma-style nesting, not real Gemma values
    nested = {
        "architectures": ["SomeMultimodalForConditionalGeneration"],
        "vision_config": {"hidden_size": 1152},
        "text_config": {
            "num_hidden_layers": 48, "hidden_size": 3840,
            "num_attention_heads": 16, "num_key_value_heads": 8,
            "head_dim": 256, "intermediate_size": 15360,
            "num_experts": 64, "num_experts_per_tok": 4,
            "vocab_size": 262144, "max_position_embeddings": 262144,
        },
    }
    f = introspect("test/nested-model", config_override=nested)
    assert f.n_layers == 48 and f.hidden_size == 3840
    assert f.attention_type == "gqa"
    assert f.is_moe and f.n_experts == 64
    assert any("multimodal" in n for n in f.notes)


def test_introspect_real_gemma4_config():
    """Fixture is the actual google/gemma-4-26B-A4B-it config.json (public)."""
    cfg = json.loads((ROOT / "configs" / "cached_model_configs" /
                      "google__gemma-4-26B-A4B-it.json").read_text())
    f = introspect("google/gemma-4-26B-A4B-it", config_override=cfg)
    assert f.is_moe and f.n_experts == 128
    assert f.experts_per_tok == 8              # via top_k_experts alias
    assert 3.0 < f.active_params_b < 5.0       # A4B
    assert 20 < f.total_params_b < 32          # 26B-class
    assert f.attention_type == "gqa" and not f.has_mtp_head
    assert any("hybrid attention" in n for n in f.notes)
