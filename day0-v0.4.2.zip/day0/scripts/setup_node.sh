#!/usr/bin/env bash
# day0 node setup — automates PREREQUISITES.md on AL2023/RHEL9-family GPU nodes.
# Idempotent; safe to re-run. Review PREREQUISITES.md for the reasoning.
# Usage: bash scripts/setup_node.sh [NVME_ROOT]   (default /mnt/local-nvme)
set -uo pipefail

NVME=${1:-/mnt/local-nvme}
VENV=$NVME/sgl_venv
PYBIN=""
FAIL=0
say()  { printf '\n=== %s ===\n' "$*"; }
ok()   { printf '  [ OK ] %s\n' "$*"; }
warn() { printf '  [WARN] %s\n' "$*"; }
bad()  { printf '  [FAIL] %s\n' "$*"; FAIL=1; }

say "0. Driver & NVMe sanity"
nvidia-smi >/dev/null 2>&1 && ok "nvidia driver: $(nvidia-smi --query-gpu=count --format=csv,noheader | head -1) GPUs" \
  || bad "nvidia-smi not working — install the driver first; this script does not."
[ -d "$NVME" ] && ok "NVMe root $NVME exists" || bad "$NVME missing — mount local NVMe first"
FREE_GB=$(df -BG --output=avail "$NVME" 2>/dev/null | tail -1 | tr -dc 0-9)
[ "${FREE_GB:-0}" -ge 200 ] && ok "free space ${FREE_GB}GB" || warn "only ${FREE_GB:-?}GB free (<200GB floor)"

say "1. OS packages"
if command -v dnf >/dev/null; then
  sudo dnf install -y -q python3.11 git unzip screen sqlite tar >/dev/null 2>&1 \
    && ok "dnf packages present" || warn "dnf install had issues — check manually"
elif command -v apt >/dev/null; then
  sudo apt-get install -y -q python3.11 python3.11-venv git unzip screen sqlite3 >/dev/null 2>&1 \
    && ok "apt packages present" || warn "apt install had issues"
fi
for c in python3.12 python3.11 python3.10; do command -v $c >/dev/null && PYBIN=$c && break; done
[ -n "$PYBIN" ] && ok "interpreter: $PYBIN" || bad "no python >= 3.10 found (3.9 CANNOT run sglang deps)"

say "2. Workspace"
mkdir -p "$NVME"/{models,pip-cache,hicache-l3} && sudo chown -R "$USER" "$NVME" 2>/dev/null
ok "layout: models/ pip-cache/ hicache-l3/"

say "3. CUDA toolkit"
if [ -d /usr/local/cuda ]; then
  ok "toolkit at /usr/local/cuda ($(/usr/local/cuda/bin/nvcc --version 2>/dev/null | grep -o 'release [0-9.]*' || echo 'nvcc?'))"
else
  warn "no /usr/local/cuda — attempting install (needs torch's CUDA major.minor; defaulting 13-0)"
  if command -v dnf >/dev/null; then
    sudo dnf config-manager --add-repo \
      https://developer.download.nvidia.com/compute/cuda/repos/amzn2023/x86_64/cuda-amzn2023.repo 2>/dev/null
    sudo dnf install -y cuda-toolkit-13-0 >/dev/null 2>&1 \
      && ok "cuda-toolkit-13-0 installed" \
      || bad "toolkit install failed — see PREREQUISITES.md §3 (incl. no-root pip fallback)"
  fi
fi

say "4. venv + sglang"
export PIP_CACHE_DIR=$NVME/pip-cache
[ -x "$VENV/bin/python" ] || $PYBIN -m venv "$VENV"
# shellcheck disable=SC1091
source "$VENV/bin/activate"
python -m pip install -q --upgrade pip
python -c "import sglang" 2>/dev/null || { echo "  installing sglang[all] (~10GB, be patient)"; python -m pip install -q "sglang[all]"; }
python -m pip install -q sglang-router 2>/dev/null || warn "sglang-router not installed (Track B/PD will be skipped)"

say "5. Dependency landmines"
export CUDA_HOME=/usr/local/cuda PATH=/usr/local/cuda/bin:$PATH LD_LIBRARY_PATH=/usr/local/cuda/lib64:${LD_LIBRARY_PATH:-}
export MKL_THREADING_LAYER=GNU
python - << 'EOF'
import importlib.util, subprocess, sys
def probe(mod):
    return subprocess.run([sys.executable, "-c", f"import {mod}"], capture_output=True, text=True)
# deep_gemm: fine if importable WITH toolkit; else must be absent (ImportError is caught upstream, OSError/assert is not)
r = probe("deep_gemm")
if importlib.util.find_spec("deep_gemm") and r.returncode != 0:
    print("  [WARN] deep_gemm present but broken (needs CUDA_HOME) -> uninstalling for bf16-only serving")
    subprocess.run([sys.executable, "-m", "pip", "uninstall", "-y", "deep-gemm", "deep_gemm"], capture_output=True)
r = probe("torchcodec")
if importlib.util.find_spec("torchcodec") and r.returncode != 0:
    print("  [WARN] torchcodec present but broken (missing ffmpeg libs) -> uninstalling (text serving unaffected)")
    subprocess.run([sys.executable, "-m", "pip", "uninstall", "-y", "torchcodec"], capture_output=True)
for order in ("import torch, numpy", "import numpy, torch"):
    rr = subprocess.run([sys.executable, "-c", order], capture_output=True, text=True)
    tag = "[ OK ]" if rr.returncode == 0 else "[FAIL]"
    print(f"  {tag} {order}")
EOF

say "6. sglang launch path"
python -c "import sglang, sglang.launch_server; print('  [ OK ] sglang', sglang.__version__, '(launch path verified)')" \
  || bad "sglang launch path broken — see PREREQUISITES.md §4/§5"

say "7. Persist environment"
BLOCK='export CUDA_HOME=/usr/local/cuda; export PATH=$CUDA_HOME/bin:$PATH; export LD_LIBRARY_PATH=$CUDA_HOME/lib64:$LD_LIBRARY_PATH; export MKL_THREADING_LAYER=GNU'
grep -q "MKL_THREADING_LAYER=GNU" ~/.bashrc 2>/dev/null || echo "$BLOCK" >> ~/.bashrc
ok "env block in ~/.bashrc (venv activation still manual per shell/screen)"

say "8. day0"
if [ -f "$NVME/day0/pyproject.toml" ]; then
  python -m pip install -q -e "$NVME/day0" && ok "day0 installed: $(day0 --help 2>/dev/null | head -1 || echo installed)"
else
  warn "day0 repo not at $NVME/day0 — unzip the release there and run: python -m pip install -e $NVME/day0"
fi

say "RESULT"
if [ "$FAIL" -eq 0 ]; then
  echo "  Setup complete. Remaining manual steps:"
  echo "    1. export HF_TOKEN=...           (gated models: accept license on the hub first)"
  echo "    2. prefetch weights:  python -c \"from huggingface_hub import snapshot_download; snapshot_download('<model>', cache_dir='$NVME/models')\""
  echo "    3. day0 preflight <job.yaml>     (must print GO)"
else
  echo "  One or more FAILs above — fix them (PREREQUISITES.md has the reasoning) and re-run."
  exit 1
fi
