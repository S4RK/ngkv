# day0 — Node Prerequisites (fresh box → first run)

Every requirement below exists because its absence broke a real run on a real
B200 node (Aug 2026). Written for **Amazon Linux 2023 / RHEL9-family** (the
`/usr/lib64` + `dnf` images our GPU nodes use); Ubuntu deltas noted where they
differ. Automated version: `scripts/setup_node.sh`. Final verification:
`day0 preflight <job.yaml>` — do not start a cluster run without a GO.

---

## 0. Assumptions

- NVIDIA **driver** already installed (`nvidia-smi` works and shows all GPUs).
  The driver alone is NOT enough — see §3.
- You have sudo, or note the no-root fallbacks marked ⓑ.
- A large local NVMe volume mounted (we use `/mnt/local-nvme`). Root
  filesystems on these images are small; nothing bulky may land outside NVMe.

## 1. OS packages

```bash
sudo dnf install -y python3.11 git unzip screen sqlite tar
# Ubuntu: sudo apt install -y python3.11 python3.11-venv git unzip screen sqlite3
```

Why each one:
- **python3.11** (3.10 minimum, 3.11/3.12 preferred). The default 3.9 on AL2023
  **cannot run the modern SGLang stack**: `compressed_tensors` uses PEP-604
  (`str | list[str]`) annotations evaluated at import — a hard SyntaxError-class
  failure on 3.9. No amount of pip surgery fixes it; you need the interpreter.
- **screen** — runs outlive SSM/SSH sessions; day0 runs are hours long.
- **sqlite** — the CLI for inspecting `runs.sqlite` (day0 itself only needs the
  Python module, which ships with CPython).
- **git** — for a shared `DAY0_KB` knowledge-base repo (recommended).

## 2. Workspace layout on NVMe

```bash
sudo mkdir -p /mnt/local-nvme/{models,pip-cache,hicache-l3}
sudo chown -R $USER /mnt/local-nvme
```

- `models/` — HF weight cache (a 26B bf16 model ≈ 51 GB; DeepSeek-class ≈ 700 GB).
- `pip-cache/` — `PIP_CACHE_DIR` target; the sglang/torch wheel set is ~10 GB
  and must not fill the root disk.
- `hicache-l3/` — hierarchical KV cache tier (Track D).
- **Free-space floor:** ≥ 2 TB comfortable; ≥ 200 GB absolute minimum for a
  single ~25B model + venv + caches.

## 3. CUDA **toolkit** (not just the driver)

The driver runs compiled kernels; SGLang 0.5.x **JIT-compiles** kernels at
startup (fused RoPE/activation via tvm_ffi; deep_gemm for FP8). JIT needs
`nvcc`, headers, and libs — a full toolkit — or the server dies at CUDA-graph
capture with `Could not find CUDA installation. Please set CUDA_HOME`.

Match the toolkit **major.minor to torch's CUDA build**:

```bash
python -c "import torch; print(torch.version.cuda)"   # e.g. 13.0 -> toolkit 13-0
```

```bash
sudo dnf config-manager --add-repo \
  https://developer.download.nvidia.com/compute/cuda/repos/amzn2023/x86_64/cuda-amzn2023.repo
sudo dnf install -y cuda-toolkit-13-0     # swap distro segment (rhel9/...) if repo 404s
```

ⓑ No-root fallback: `pip install nvidia-cuda-nvcc-cu13 nvidia-cuda-runtime-cu13
nvidia-cuda-cccl-cu13` and symlink a synthetic `CUDA_HOME` tree (bin/nvvm from
cuda_nvcc; include/ and lib64/ merged from all three wheels).

**Gotcha that cost us an hour:** the toolkit may already be installed but
invisible — nothing works until the env vars in §7 are set. Check
`ls -d /usr/local/cuda*` before installing.

## 4. Python venv + SGLang

```bash
export PIP_CACHE_DIR=/mnt/local-nvme/pip-cache
python3.11 -m venv /mnt/local-nvme/sgl_venv
source /mnt/local-nvme/sgl_venv/bin/activate
python -m pip install --upgrade pip
python -m pip install "sglang[all]"          # pulls torch + CUDA wheels, ~10 GB
python -m pip install sglang-router          # optional: needed only for PD (Track B)
```

Requirements on the SGLang build itself:
- **Version floor is model-dependent.** Gemma 4 (hybrid sliding-window
  attention) needs a build from ~May 2026 or later; verified good on 0.5.17.
  An older sglang "successfully installed" is worthless if it predates your
  model's architecture — check the release notes against the model family.
- If `pip` isn't on PATH inside the venv (seen with some venv builds), use
  `python -m pip` — identical.
- Verify the **launch path**, not just importability (a half-broken install
  passes `import sglang` and dies later):

```bash
python -c "import sglang, sglang.launch_server; print(sglang.__version__)"
```

## 5. Known dependency landmines (each one took down a run)

| Package | Symptom | Fix |
|---|---|---|
| **deep_gemm** | `AssertionError` in `find_cuda_home()` during **arg parsing** — every launch dies instantly | Install the CUDA toolkit (§3). It's only needed for FP8 GEMMs — for bf16-only serving, `python -m pip uninstall -y deep-gemm` (or `mv site-packages/deep_gemm deep_gemm.disabled` if pip has no metadata for it) is a clean disable: absence raises ImportError, which SGLang catches |
| **torchcodec** | `OSError: libavutil.so.56: cannot open shared object file` — present-but-broken escapes SGLang's ImportError guard | It's video decoding for multimodal input. Text serving: `python -m pip uninstall -y torchcodec`. If the model's processor demands it: reinstall + `sudo dnf install -y ffmpeg-libs` (may need an extra repo) |
| **MKL threading** | `Intel oneMKL FATAL ERROR: Cannot load ... libtorch_cpu.so` — import-order dependent, can hit the bench client not the engine | `export MKL_THREADING_LAYER=GNU` (§7). Verify both orders: `python -c "import torch, numpy"` and `python -c "import numpy, torch"` |

## 6. HuggingFace access + weight prefetch

```bash
export HF_TOKEN=hf_xxxx        # gated models (Gemma, Llama): accept the license on the repo page FIRST
python -c "from huggingface_hub import snapshot_download; \
  snapshot_download('<org>/<model>', cache_dir='/mnt/local-nvme/models')"
```

**Always prefetch before the first day0 run.** A cold download inside a trial's
health-check window (900 s) makes a slow network look like a crashed engine.

## 7. Environment block (the non-negotiable four)

Every shell that launches day0 — **including every fresh screen session**, which
starts a clean shell — needs:

```bash
source /mnt/local-nvme/sgl_venv/bin/activate
export CUDA_HOME=/usr/local/cuda
export PATH=$CUDA_HOME/bin:$PATH
export LD_LIBRARY_PATH=$CUDA_HOME/lib64:$LD_LIBRARY_PATH
export MKL_THREADING_LAYER=GNU
```

Persist the exports in `~/.bashrc`; the venv activation still has to be typed
(or added to `.bashrc` too if this box is dedicated). day0's engine subprocesses
inherit this environment — one correct shell covers all trials.

## 8. day0 itself

```bash
cd /mnt/local-nvme && unzip -o day0-vX.Y.Z.zip && cd day0
python -m pip install -e .
```

Optional shared stores: `export DAY0_REGISTRY=<shared path>` (measured-run
warm-starts), `export DAY0_KB=<shared path or git checkout>` (curated knowledge
base). `agate` on PATH enables the Stage-4 accuracy gate; without it the gate
is recorded SKIPPED — acceptable for exploration, mandatory before production
promotion.

## 9. Node hygiene (before every run)

```bash
# ports free (day0 uses 30000 router/engine, 30001 prefill, 30011 decode)
for p in 30000 30001 30011; do (echo > /dev/tcp/127.0.0.1/$p) 2>/dev/null && echo "PORT $p BUSY"; done

# GPUs clean — orphaned engines hold HBM and produce
# "memory capacity is unbalanced" on the next launch
nvidia-smi --query-compute-apps=pid,used_memory --format=csv
# if occupied: pkill -9 -f sglang; sleep 3; re-check (~0 MiB everywhere)
```

day0 ≥ 0.3.7 refuses to start on dirty GPUs and reaps its own engines on any
exit path — but `kill -9` on day0 itself bypasses atexit, so the manual check
stays in the ritual.

## 10. Final verification

```bash
day0 preflight <job.yaml>
```

GO required. The preflight covers: GPU count, **sglang launch-path import with
version** (subprocess-verified — catches the broken-install case), router
presence (Track B), NVMe space + model cache, ports, EFA devices (multi-node),
agate. Then a recommended one-time smoke launch of the target model
(`python -m sglang.launch_server --model-path <model> --tp-size <N> ...`) to
ready + `/health`, Ctrl-C, and hand over to `day0 run`.

## Appendix — failure → cause cheat sheet (all observed live)

| You see | It means |
|---|---|
| `requires a different Python: 3.9.x` | venv on system 3.9 — rebuild on 3.11+ (§1/§4) |
| `unsupported operand type(s) for \|` at import | same root cause, hit at runtime |
| deep_gemm `assert cuda_home is not None` | toolkit missing/invisible (§3, §5) |
| `libavutil.so.56: cannot open` | torchcodec vs missing ffmpeg (§5) |
| `oneMKL FATAL ERROR ... libtorch_cpu.so` | MKL threading layer (§5, §7) |
| `Could not find CUDA installation` at graph capture | env block missing in this shell (§7) |
| `error: unrecognized arguments: --enable-ep-moe` | pre-0.5.x flag; upgrade day0 (handled ≥ 0.3.4) |
| `hidden size must be divisible by vector size` | model×kernel constraint — see `kb/` entry, not an env issue |
| `memory capacity is unbalanced` | orphaned engines on GPUs (§9) |
| First trial "crash" on a brand-new model | probably cold weight download — prefetch (§6) |
